-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: ytasker
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ytasker`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ytasker` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ytasker`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@admin.com','$2y$10$G8ILTi8Gmte4Te51RNAj2OiQ2zI5H3SNUfypMHV/MYoAe7J1v8XJ2','lPUuPlbiFuznm8ul3ge2qaThv3l8rhVJFvfaHeqwjYCQfxJ0r2FJo4VZArqM',NULL,'2017-11-21 02:40:16','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL,
  `title` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `photo` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_group_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_group_image` text COLLATE utf8_unicode_ci,
  `category_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(10) unsigned DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'abc','cat-group1','cat-group1','cat-group1','1500123991s3.png',NULL,'',0,1,1,'2017-07-12 16:00:20','2017-07-16 13:18:42'),(2,NULL,'cat-group-2','cat-group-2','cat-group-2','1500124866ss.png',NULL,'',0,1,1,'2017-07-15 06:35:33','2017-07-24 07:17:21'),(4,NULL,'cat-group-3','cat-group-3','cat-group-3','1500123991s3.png','1500131225s2.png','sdfdsf',0,1,1,'2017-07-15 09:37:05','2017-07-24 07:17:35'),(7,NULL,'cat1','cat1','cat-group1','1500123991s3.png','1500136292s4.png','',1,2,1,'2017-07-15 11:01:32','2017-07-24 07:17:58'),(8,NULL,'cat2','cat2','cat-group-2','1500124866ss.png','1500137481s2.png','desc',2,2,1,'2017-07-15 11:21:21','2017-07-24 07:18:10'),(9,NULL,'cat3','cat3','cat-group-3','1500123991s3.png','1500137558s3.png','',4,2,1,'2017-07-15 11:22:38','2017-07-24 07:18:23'),(10,NULL,'home-furniture','Home & Furniture','Home & Furniture','1507005434Cleaning.png',NULL,'Group responsible for home jobs and stuffs',0,1,1,'2017-10-03 04:37:14','2017-10-03 04:37:14'),(11,NULL,'','Cleaning ','Home & Furniture','1507005434Cleaning.png','1507005500Supply_hire.png','Home vegetables cutting and cleaning ',10,2,1,'2017-10-03 04:38:20','2017-10-03 04:38:20'),(12,NULL,'','Furniture cleaning ','Home & Furniture','1507005434Cleaning.png','1507005604Waiting_staff.png','clean furniture',10,2,1,'2017-10-03 04:40:04','2017-10-03 04:40:04');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryDashboard`
--

DROP TABLE IF EXISTS `categoryDashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryDashboard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `display_order` int(10) DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryDashboard`
--

LOCK TABLES `categoryDashboard` WRITE;
/*!40000 ALTER TABLE `categoryDashboard` DISABLE KEYS */;
INSERT INTO `categoryDashboard` VALUES (2,'cat2',1,8,'2017-10-03 04:35:53','2017-10-03 04:35:53'),(3,'cat3',1,9,'2017-10-03 04:35:59','2017-10-03 04:35:59'),(4,'Cleaning ',1,11,'2017-10-03 04:39:20','2017-10-03 04:39:20'),(5,'cat1',1,7,'2017-10-28 15:45:27','2017-10-28 15:45:27');
/*!40000 ALTER TABLE `categoryDashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_group`
--

DROP TABLE IF EXISTS `category_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_group` (
  `id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `group_description` varchar(255) NOT NULL,
  `group_image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_group`
--

LOCK TABLES `category_group` WRITE;
/*!40000 ALTER TABLE `category_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userId` int(10) DEFAULT NULL,
  `commentId` int(10) DEFAULT '0',
  `taskId` int(10) DEFAULT NULL,
  `commentDescription` longtext,
  `commentDate` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,65,NULL,7,'desc','2017-12-12','2017-11-20 18:03:46','2017-11-20 18:03:46'),(9,65,NULL,7,'desc',NULL,'2017-11-21 00:12:05','2017-11-21 00:12:05'),(10,88,0,66,'Happy to do this for you. Check my airtask reviews and portfolio and give me a chance. I have an experience of this type of task. I will try my best to do this for you and I will give you unlimited revision until you are satisfied.',NULL,'2017-11-22 10:08:55','2017-11-22 10:08:55'),(11,88,0,66,'Happy to do this for you. Check my airtask reviews and portfolio and give me a chance. I have an experience of this type of task. I will try my best to do this for you and I will give you unlimited revision until you are satisfied.',NULL,'2017-11-22 10:09:09','2017-11-22 10:09:09'),(12,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:44','2017-11-22 17:41:44'),(13,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:46','2017-11-22 17:41:46'),(14,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:48','2017-11-22 17:41:48'),(15,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:48','2017-11-22 17:41:48'),(16,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:48','2017-11-22 17:41:48'),(17,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:50','2017-11-22 17:41:50'),(18,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:50','2017-11-22 17:41:50'),(19,99,0,68,'I am in parramatta would there in 10 minuets Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-22 17:41:51','2017-11-22 17:41:51'),(20,86,10,66,'i m interested',NULL,'2017-11-23 09:14:18','2017-11-23 09:14:18'),(21,99,0,66,'I am happy to do this for you,Please review my portfolio',NULL,'2017-11-24 14:55:27','2017-11-24 14:55:27'),(22,88,0,66,'I m interested and will give you 15% discount',NULL,'2017-11-24 23:54:49','2017-11-24 23:54:49'),(23,88,0,66,'I m interested and will give you 15% discount',NULL,'2017-11-24 23:55:27','2017-11-24 23:55:27'),(24,88,0,67,'Offer includes 15% Airtasker fees and a man with van',NULL,'2017-11-24 23:57:44','2017-11-24 23:57:44'),(25,88,21,66,'will give you 15% discount',NULL,'2017-11-25 00:00:11','2017-11-25 00:00:11'),(26,87,20,66,'ok ',NULL,'2017-11-25 00:06:20','2017-11-25 00:06:20'),(27,87,20,66,'hi ... plz send more details',NULL,'2017-11-25 01:16:09','2017-11-25 01:16:09'),(28,88,20,66,'sure.',NULL,'2017-11-25 01:22:59','2017-11-25 01:22:59'),(29,88,24,67,'i m interested ',NULL,'2017-11-25 01:28:51','2017-11-25 01:28:51'),(30,88,0,7,'i m interested ',NULL,'2017-11-25 01:31:23','2017-11-25 01:31:23'),(31,88,0,7,'i m interested ',NULL,'2017-11-25 01:31:23','2017-11-25 01:31:23'),(32,88,30,7,'ok',NULL,'2017-11-25 01:31:35','2017-11-25 01:31:35'),(33,99,31,7,'sure',NULL,'2017-11-25 11:55:36','2017-11-25 11:55:36'),(34,99,31,7,'Let me know when you start ?',NULL,'2017-11-25 11:56:44','2017-11-25 11:56:44'),(35,99,0,68,'i am interested ',NULL,'2017-11-25 15:02:41','2017-11-25 15:02:41'),(36,62,0,68,'test',NULL,'2017-11-25 15:04:51','2017-11-25 15:04:51'),(37,62,0,67,'i m interested',NULL,'2017-11-25 15:13:01','2017-11-25 15:13:01'),(38,62,0,67,'i m interested',NULL,'2017-11-25 15:13:41','2017-11-25 15:13:41'),(39,99,0,66,'i m interesred please review my portfolio',NULL,'2017-11-25 15:21:28','2017-11-25 15:21:28'),(40,62,0,65,'i m interested ',NULL,'2017-11-25 15:27:34','2017-11-25 15:27:34'),(41,99,0,68,'t3st',NULL,'2017-11-25 15:59:09','2017-11-25 15:59:09'),(42,99,0,65,NULL,NULL,'2017-11-25 16:02:52','2017-11-25 16:02:52'),(43,99,0,65,NULL,NULL,'2017-11-25 16:09:16','2017-11-25 16:09:16'),(44,99,0,65,NULL,NULL,'2017-11-25 16:09:51','2017-11-25 16:09:51'),(45,99,0,65,'test comment',NULL,'2017-11-25 16:10:18','2017-11-25 16:10:18'),(46,62,42,65,NULL,NULL,'2017-11-25 22:50:35','2017-11-25 22:50:35'),(47,62,42,65,NULL,NULL,'2017-11-25 22:50:36','2017-11-25 22:50:36'),(48,62,42,65,NULL,NULL,'2017-11-25 22:50:36','2017-11-25 22:50:36'),(49,62,42,65,NULL,NULL,'2017-11-25 22:50:36','2017-11-25 22:50:36'),(50,62,42,65,NULL,NULL,'2017-11-25 22:50:36','2017-11-25 22:50:36'),(51,62,40,65,'ok',NULL,'2017-11-25 22:55:41','2017-11-25 22:55:41'),(52,62,10,66,'cool ...\n',NULL,'2017-11-26 13:09:48','2017-11-26 13:09:48'),(53,94,0,66,'I am happy to do it now !!',NULL,'2017-11-27 09:32:29','2017-11-27 09:32:29'),(54,94,21,66,'That\'s a nice discount',NULL,'2017-11-27 09:33:05','2017-11-27 09:33:05'),(55,94,0,66,'0452369856 contact me',NULL,'2017-11-27 09:33:39','2017-11-27 09:33:39'),(56,99,22,66,'sure',NULL,'2017-11-27 15:18:06','2017-11-27 15:18:06'),(57,99,21,66,'thanks for response',NULL,'2017-11-27 15:28:36','2017-11-27 15:28:36'),(58,99,21,66,'thanks for response',NULL,'2017-11-27 15:28:44','2017-11-27 15:28:44'),(59,99,0,69,'i m interested',NULL,'2017-11-27 16:36:55','2017-11-27 16:36:55'),(60,99,59,69,'thanks for response',NULL,'2017-11-27 16:37:42','2017-11-27 16:37:42'),(61,99,0,69,NULL,NULL,'2017-11-27 16:41:33','2017-11-27 16:41:33'),(62,99,43,65,'ok',NULL,'2017-11-27 19:16:44','2017-11-27 19:16:44'),(63,99,61,69,'ok',NULL,'2017-11-27 19:23:34','2017-11-27 19:23:34'),(64,99,61,69,'cool',NULL,'2017-11-27 19:33:30','2017-11-27 19:33:30');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_fields`
--

DROP TABLE IF EXISTS `contact_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_fields` (
  `id` int(10) unsigned NOT NULL,
  `contactId` int(10) unsigned DEFAULT NULL,
  `fieldKey` varchar(255) DEFAULT NULL,
  `fieldValue` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_fields`
--

LOCK TABLES `contact_fields` WRITE;
/*!40000 ALTER TABLE `contact_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_groups`
--

DROP TABLE IF EXISTS `contact_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupName` varchar(255) DEFAULT NULL,
  `groupCategory` varchar(255) DEFAULT NULL,
  `contactId` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_groups`
--

LOCK TABLES `contact_groups` WRITE;
/*!40000 ALTER TABLE `contact_groups` DISABLE KEYS */;
INSERT INTO `contact_groups` VALUES (9,'my group',NULL,NULL,0,NULL,NULL,NULL,'2017-10-18 00:15:20','2017-11-20 11:31:52'),(11,'my group',NULL,3,9,'monika@gmail.com','monika',NULL,'2017-10-18 00:15:20','2017-11-20 11:31:52'),(12,'my group',NULL,2,9,'kanikasethi04@gmail.com','kanika',NULL,'2017-10-18 00:15:20','2017-11-20 11:31:52');
/*!40000 ALTER TABLE `contact_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `categoryId` int(10) unsigned DEFAULT NULL,
  `categoryName` text,
  `user_id` int(10) unsigned DEFAULT NULL,
  `address` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'Mr.','','ramesh','','kandy','kroy@gmail.com',NULL,'8103194076',NULL,'1,2',NULL,'Kundan roy ','2017-09-14 12:46:37','2017-10-18 00:11:30'),(2,'mr',NULL,'Suresh',NULL,'kanika','kanikasethi04@gmail.com',NULL,'8109264446',NULL,NULL,NULL,'Kundan roy ','2017-10-03 04:42:00','2017-10-18 00:11:56'),(3,'Mr.','','monika','','monika','monika@gmail.com',NULL,'9826916395',NULL,'Array',NULL,'monika','2017-10-03 04:57:35','2017-10-14 00:59:43'),(4,'Mrs.','','Anandi','Dubey',NULL,'rbsartistry@infowayindia.in',NULL,'7999506748',NULL,'1',NULL,'Indore\r\nmp','2017-10-14 00:58:12','2017-10-14 00:58:12'),(5,'Mr.','Project Manager','Manoj','Prasad',NULL,'manoj.i.prasad@gmail.com',NULL,'8767572614',NULL,'1',NULL,'Kokan nagar Bhandup West','2017-11-20 11:24:54','2017-11-20 11:24:54');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_supports`
--

DROP TABLE IF EXISTS `customer_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_supports` (
  `id` int(10) NOT NULL,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_supports`
--

LOCK TABLES `customer_supports` WRITE;
/*!40000 ALTER TABLE `customer_supports` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2017_03_12_221035_create_admin_table',1),('2017_03_12_221035_create_assignments_table',1),('2017_03_12_221035_create_courses_table',1),('2017_03_12_221035_create_password_resets_table',1),('2017_03_12_221035_create_permission_role_table',1),('2017_03_12_221035_create_permissions_table',1),('2017_03_12_221035_create_professor_profiles_table',1),('2017_03_12_221035_create_role_user_table',1),('2017_03_12_221035_create_roles_table',1),('2017_03_12_221035_create_student_courses_table',1),('2017_03_12_221035_create_student_profiles_table',1),('2017_03_12_221035_create_users_table',1),('2017_03_12_221037_add_foreign_keys_to_assignments_table',1),('2017_03_12_221037_add_foreign_keys_to_courses_table',1),('2017_03_12_221037_add_foreign_keys_to_permission_role_table',1),('2017_03_12_221037_add_foreign_keys_to_professor_profiles_table',1),('2017_03_12_221037_add_foreign_keys_to_role_user_table',1),('2017_03_12_221037_add_foreign_keys_to_student_courses_table',1),('2017_03_12_221037_add_foreign_keys_to_student_profiles_table',1),('2017_03_18_071810_add_column_to_courses_table',2),('2017_03_18_072721_add_column_to_assignments_table',2),('2017_03_18_194033_create_syllabus_table',2),('2017_03_26_063346_update_email_to_users_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `taskId` int(10) DEFAULT NULL,
  `assignUserId` int(10) DEFAULT NULL,
  `interestedUsreId` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers`
--

LOCK TABLES `offers` WRITE;
/*!40000 ALTER TABLE `offers` DISABLE KEYS */;
INSERT INTO `offers` VALUES (4,65,NULL,85,'2017-11-27 19:38:13','2017-11-27 20:26:16');
/*!40000 ALTER TABLE `offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `page_content` text,
  `creeated_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tasks`
--

DROP TABLE IF EXISTS `post_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locationType` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `typeOfPeople` text COLLATE utf8_unicode_ci,
  `totalAmount` float(10,2) DEFAULT '0.00',
  `paymentMode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hourlyRate` float(10,2) DEFAULT '0.00',
  `totalHours` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `dueDate` date DEFAULT NULL,
  `peopleRequired` int(11) DEFAULT NULL,
  `budget` int(11) DEFAULT NULL,
  `budgetType` mediumtext COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tasks`
--

LOCK TABLES `post_tasks` WRITE;
/*!40000 ALTER TABLE `post_tasks` DISABLE KEYS */;
INSERT INTO `post_tasks` VALUES (7,'Clean my 1 bedroom service','Clean my 1  bedroom service and 1 bathroom service along with vaccum cleaner','Come to work place','melbourne','452005','Looking for multiple people',1000.00,NULL,0.00,'0',88,NULL,NULL,NULL,'Total','open','2017-10-31 04:27:32','2017-10-31 04:27:32'),(65,'wash my scooter','wash my scooter parked in front of lawn ','Work remotely',NULL,NULL,NULL,50.00,NULL,0.00,'0',88,'2017-11-21',NULL,NULL,'Total','open','2017-11-20 22:42:00','2017-11-20 22:42:00'),(66,'2x Hospitality Staff needed for Xmas party 7/12/17','2x Hospitality Staff needed for a corporate rooftop Xmas party from 3pm-9pm Thursday 7/12/17.\nTasks will include:\n•General setup, \n•Food Prep (cheese boards and canapés)\n•Serving food\n•Bar Work\n•Assisting with clean up/pack up','Come to work place','Melbourne VIC 3004, Australia','3004',NULL,5000.00,NULL,0.00,'0',88,'2017-12-11',NULL,NULL,'Total','open','2017-11-20 23:10:45','2017-11-20 23:10:45'),(67,'wash my activa','activa and car wash with jet spray','Come to work place','melbourne','3003',NULL,600.00,NULL,5.00,'120',88,'2017-11-21',NULL,NULL,'Per Hour','open','2017-11-20 23:23:33','2017-11-20 23:23:33'),(68,'Clean my Room','FhkbvjkvhjkkvvvvvVjhgbhhjkhfgjjgfghhfcvbjgfggg','Come to work place',NULL,NULL,NULL,50.00,NULL,0.00,'0',109,'2017-11-21',NULL,NULL,'Total','open','2017-11-21 17:23:37','2017-11-21 17:23:37'),(69,'Clean my bike','Clean my bike abcd, Clean my bike abcd','Come to work place','Indore','452012',NULL,5.00,NULL,1.00,'5',110,'2016-09-01',NULL,NULL,'Per Hour','open','2017-11-25 16:25:12','2017-11-25 16:25:12');
/*!40000 ALTER TABLE `post_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL,
  `product_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_category` int(10) unsigned DEFAULT NULL,
  `product_sub_category` int(10) unsigned DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `qty` int(10) unsigned DEFAULT '1',
  `discount` float(10,2) NOT NULL DEFAULT '0.00',
  `description` mediumtext COLLATE utf8_unicode_ci,
  `photo` mediumtext COLLATE utf8_unicode_ci,
  `product_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validity` int(10) unsigned DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `total_stocks` int(10) unsigned DEFAULT NULL,
  `available_stocks` int(10) unsigned DEFAULT NULL,
  `views` int(10) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programms`
--

DROP TABLE IF EXISTS `programms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) DEFAULT NULL,
  `description` text,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `target_users` varchar(255) DEFAULT NULL,
  `complete_task` int(10) DEFAULT NULL,
  `reward_point` float DEFAULT NULL,
  `created_by` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programms`
--

LOCK TABLES `programms` WRITE;
/*!40000 ALTER TABLE `programms` DISABLE KEYS */;
INSERT INTO `programms` VALUES (1,'Program','dfdsfds','02/10/2017','11/10/2017','last_15_days',0,0,NULL,'2017-09-25 18:30:00','2017-10-01 16:38:34'),(3,'program1','desc','01/10/2017','30/10/2017','last_30_days',1,2,NULL,'2017-10-01 10:30:23','2017-10-01 10:30:42'),(4,'Xmas targeting ','kanika','30/10/2017','31/12/2017','last_30_days',5,67,NULL,'2017-10-03 05:08:34','2017-10-03 05:09:24'),(5,'kanika bday','fffffffffffffffff','19/10/2017','21/10/2017','last_15_days',0,0,NULL,'2017-10-13 21:17:56','2017-10-13 21:17:56'),(6,'program','hii','19/10/2017','21/10/2017','last_15_days',5,1,NULL,'2017-10-13 21:18:50','2017-10-13 21:18:50');
/*!40000 ALTER TABLE `programms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','admin','admin',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saveTask`
--

DROP TABLE IF EXISTS `saveTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saveTask` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `taskId` int(10) unsigned DEFAULT NULL,
  `userId` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saveTask`
--

LOCK TABLES `saveTask` WRITE;
/*!40000 ALTER TABLE `saveTask` DISABLE KEYS */;
INSERT INTO `saveTask` VALUES (1,1,65,'2017-11-27 20:57:01','2017-11-27 20:57:01'),(2,2,65,'2017-11-27 20:57:01','2017-11-27 20:57:01');
/*!40000 ALTER TABLE `saveTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL,
  `field_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `support_type` varchar(255) DEFAULT NULL,
  `subject` tinytext,
  `description` text,
  `ticket_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `coupan_id` int(11) unsigned DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_price` float(10,2) DEFAULT NULL,
  `discount_price` float(10,2) DEFAULT '0.00',
  `transaction_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (62,'k','r',NULL,NULL,'','shashi.shrivas@gmail.com','$2y$10$mRGfVcw95tbb0WMG/vCD8OP6a77kBSgNBd8Wm/jQ3YaEci.YZ92YG',NULL,0,'2017-09-28 12:08:10','2017-09-28 12:08:10'),(81,'sha','sh',NULL,NULL,'','ss@gmail.com','$2y$10$owIx4h.pD0oFVj4xctTdXOEP3m0pBZUT3nZwMJ28UdElvUZNMGVAm',NULL,1,'2017-10-09 17:21:35','2017-10-09 17:21:35'),(83,'resh','jack',NULL,NULL,'','reshkshanaa13@gmail.com','$2y$10$HNV9zJ.nMaOp/DNPUhnBBuPV68rUv0XW4SEEE6NvdEPW7nl45pv1W',NULL,1,'2017-10-10 07:40:45','2017-10-10 07:40:45'),(84,NULL,NULL,NULL,'8109264446','1','harish@admin.com','$2y$10$aQUh4mMb/cE3RLIv7lL3.OJ4EjOGb3cC5jVN9tv4ThvgtTnAKdn5S',NULL,1,'2017-10-12 19:02:29','2017-10-12 19:02:29'),(85,'mohit','sethi',NULL,NULL,'','mohit@gmail.com','$2y$10$zEJiOP.08toNpWrAX0m4Ne2v5HP0CShIumbxIhlYpzacrEnoDZot6',NULL,1,'2017-10-14 09:18:15','2017-10-14 09:18:15'),(86,'sumit','yadav',NULL,NULL,'','sumit@gmail.com','$2y$10$mBpjk8cfOdm0QQEjOS4J4.RMEiUBXstUXuUIoKXVgaGyNtpDlJ6aW',NULL,1,'2017-10-14 09:20:54','2017-10-14 09:20:54'),(87,'rama','sethi',NULL,NULL,'','rama@gmail.com','$2y$10$1LUkjH1Hm6zhBh2kFg7p3OCly.YrBPcvKwgq2q8HsTtID/Lj1gBUq',NULL,1,'2017-10-14 09:45:50','2017-10-14 09:45:50'),(88,'kanika','',NULL,NULL,'','kanika@gmail.com','$2y$10$Q94Lo6iSm2CdFRusQ4lK3OuYuqlMZu6gSn25ZqRwROuKCOPmDZXO6',NULL,1,'2017-10-14 10:05:54','2017-10-14 10:05:54'),(89,'kanika','sethi',NULL,NULL,'','kanikasethi0427@gmail.com','$2y$10$r08B3cPJMfPAaHpFVCFsO.SImKPp0x2k1SGOdKBGLej6HzViQpC4a',NULL,1,'2017-10-14 10:06:58','2017-10-14 10:06:58'),(90,'monika','yadav',NULL,NULL,'','monika@gmail.com','$2y$10$KQLQi/wapE1OmxmK2I0Qie02fuCALmB./wUfHjwYWiduSTnmdUsX.',NULL,1,'2017-10-14 11:03:19','2017-10-14 11:03:19'),(91,'kanika','sethi',NULL,NULL,'','kanika44427@mailinator.com','$2y$10$ivpIlANYTl/Pysucm3s7FOTcgY6QntqOND7l0jmPI13fxBk07g7fC',NULL,1,'2017-10-14 11:05:54','2017-10-14 11:05:54'),(92,'test','test',NULL,NULL,'','test@t.com','$2y$10$4t.nvjhNJ9UeP66TjQ3feulEr7qcqU33kQu6L5D38l/3szSA4EE/6',NULL,1,'2017-10-16 08:32:33','2017-10-16 08:32:33'),(93,'sumit','yadav',NULL,NULL,'','sumityadav@gmail.com','$2y$10$afpKrADdWjiDE3gjKZzFiOgDPTvxgFXjg6zHc2lQ1dnyxpaKtf2qu',NULL,1,'2017-10-16 19:15:44','2017-10-16 19:15:44'),(94,'test','test1',NULL,NULL,'','test@test.com','$2y$10$H.VVQZ5z53EE1x.TBY/IxOJDo9VM7W/VD3KgvsDLGjjN4vjLZsz1C',NULL,1,'2017-10-29 11:37:21','2017-10-29 11:37:21'),(95,'Sumit','',NULL,NULL,'','sumit44427@gmail.com','$2y$10$MlKgAGZYkN4EzFNXdroos.gm9XPiAQKk32E56vnA6D8pKQHxPr99i',NULL,1,'2017-11-01 19:01:15','2017-11-01 19:01:15'),(96,'dfsdfsdfsd','fsdfsdfsdf',NULL,NULL,'','fsdfsdfsd@gmal.com','$2y$10$snzflq.ypkC7smKs8AxOmeDCR64/atg9xa90VOKL6k1dCc/fDybZa',NULL,1,'2017-11-04 14:45:38','2017-11-04 14:45:38'),(97,'kanika','sethi',NULL,NULL,'','kanika678@gmail.com','$2y$10$uYCOMdCjUlPPdtgS.NlFLO51NsDg7war8D2rdAIqo9zll1QbibdMi',NULL,1,'2017-11-04 15:24:06','2017-11-04 15:24:06'),(98,'murali','valayutham',NULL,NULL,'','murali.valayutham@yahoo.com','$2y$10$sqRxqjbjUKtyjIjVr2xbkOQinaWSrxXV4LJMIfWlyqadgzMGFqS/6',NULL,1,'2017-11-06 06:31:05','2017-11-06 06:31:05'),(99,'test','demo',NULL,NULL,'','aj@gmail.com','$2y$10$.4Ycs4caL0Baxrg226.D/e/RcI8qNrbQVzjIIdAUNWeuoQ2kK3yOm',NULL,1,'2017-11-07 16:14:55','2017-11-07 16:14:55'),(100,'some','test',NULL,NULL,'','test1@test.com','$2y$10$JhyWf06E/ctz8/vivk/BxOR.55594DzB1OwclfeNvMHjS1gG2lCwG',NULL,1,'2017-11-08 14:47:57','2017-11-08 14:47:57'),(101,'Arpan','Gupta',NULL,NULL,'','arpan.gupta@mailinator.com','$2y$10$eFApV1iQ4H68Zr0k6q3VxufhjCxvJyHPjlRdK/Mpi7wpZU6KEakUy',NULL,1,'2017-11-09 23:40:23','2017-11-09 23:40:23'),(102,'Arpan','Gupta',NULL,NULL,'','arpangupta@mailinator.com','$2y$10$jHy7vt.zUa0JWc8BAuSPMuKuYIYLVbSd9YQLEkMNMDNjmFWgjrNPW',NULL,1,'2017-11-11 17:05:37','2017-11-11 17:05:37'),(103,'Arpan','Gupta',NULL,NULL,'','arpangupta1@mailinator.com','$2y$10$M4lW424a25PExfiou9AzNelCgh7CJ2Ikp/zYXVs0pYH9lXpZQnWEm',NULL,1,'2017-11-11 17:07:17','2017-11-11 17:07:17'),(104,'vaibhav','kasar',NULL,NULL,'','vaibhavdeveloper2014@gmail.com','$2y$10$bHk38l0/Xau2cOuEfD7bv.M8rc7oVtj9/l0CGINWW5s1aOkYcLNEO',NULL,1,'2017-11-11 17:22:01','2017-11-11 17:22:01'),(105,'shubhan','chawda',NULL,NULL,'','chawdas@gmail.com','$2y$10$HkQpqBF2moaUczRAM.0B7uKNVLxXH81cZvpKFkcxQ7d4DEMNlGi5i',NULL,1,'2017-11-13 12:48:35','2017-11-13 12:48:35'),(106,'mohit','',NULL,NULL,'','mohit0286@gmail.com','$2y$10$.BYTQn/L5vGXSSC0c94XYeMGzPqa/kNz0rhIWZj8FknTswJb8r4OO',NULL,1,'2017-11-18 08:30:41','2017-11-18 08:30:41'),(107,'test user','demo',NULL,NULL,'','manish@gmail.com','$2y$10$/ordZm37T5Lyf4DkqDN6yOWPg3OZzsKUemyfVs4jgAzA63B7LDRbC',NULL,1,'2017-11-20 15:04:56','2017-11-20 15:04:56'),(108,'tesy','devloper',NULL,NULL,'','dev@gmail.com','$2y$10$cfyKYEY/FbQz4A4/qfjdUOAeNAZj/iFeYPwkXZfoJ5k1hrhMVE0QW',NULL,1,'2017-11-20 15:17:35','2017-11-20 15:17:35'),(109,'Raj','Resh',NULL,NULL,'','tronprivate@gmail.com','$2y$10$y/48HzwXl9.Oqe9sk0yVPOJFYMbMu2OsDRR7JGfUa3o9JhXPY8Z/S',NULL,1,'2017-11-21 09:33:34','2017-11-21 09:33:34'),(110,'Arpan','Gupta',NULL,NULL,'','arpangupta100@mailinator.com','$2y$10$UXcGYnV8FnE34wCFxyFu..nCIi.cR78zNEPkkHwoiDm6ZLwoSnoxO',NULL,1,'2017-11-25 15:30:59','2017-11-25 23:52:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yt_tasks`
--

DROP TABLE IF EXISTS `yt_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yt_tasks` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `people_required` int(11) NOT NULL,
  `budget` int(11) NOT NULL,
  `budget_type` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yt_tasks`
--

LOCK TABLES `yt_tasks` WRITE;
/*!40000 ALTER TABLE `yt_tasks` DISABLE KEYS */;
INSERT INTO `yt_tasks` VALUES (1,'Need servicing of refrigerator','I need a picture frame picked up from Sunshine North and delivered to Belmont. Will fit in back seat or boot.Can anyone do this today. I will have this ready about 10.30am.',23,'2017-07-25',2,250,'Hourly','2017-07-24 18:50:10','2017-07-24 18:50:10');
/*!40000 ALTER TABLE `yt_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ytasker'
--

--
-- Dumping routines for database 'ytasker'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-28 12:00:10
