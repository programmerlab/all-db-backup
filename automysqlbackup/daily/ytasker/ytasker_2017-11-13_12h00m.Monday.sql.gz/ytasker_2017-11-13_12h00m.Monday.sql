-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: ytasker
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ytasker`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ytasker` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ytasker`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@admin.com','$2y$10$G8ILTi8Gmte4Te51RNAj2OiQ2zI5H3SNUfypMHV/MYoAe7J1v8XJ2','P7Bl5FDGKUGPpPbp5Xi1ayhpULRLoUNLmxmeAdXWU10PFN0ndSa7wRDiAdxL',NULL,'2017-10-12 20:49:19','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL,
  `title` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `photo` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_group_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_group_image` text COLLATE utf8_unicode_ci,
  `category_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(10) unsigned DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'abc','cat-group1','cat-group1','cat-group1','1500123991s3.png',NULL,'',0,1,1,'2017-07-12 16:00:20','2017-07-16 13:18:42'),(2,NULL,'cat-group-2','cat-group-2','cat-group-2','1500124866ss.png',NULL,'',0,1,1,'2017-07-15 06:35:33','2017-07-24 07:17:21'),(4,NULL,'cat-group-3','cat-group-3','cat-group-3','1500123991s3.png','1500131225s2.png','sdfdsf',0,1,1,'2017-07-15 09:37:05','2017-07-24 07:17:35'),(7,NULL,'cat1','cat1','cat-group1','1500123991s3.png','1500136292s4.png','',1,2,1,'2017-07-15 11:01:32','2017-07-24 07:17:58'),(8,NULL,'cat2','cat2','cat-group-2','1500124866ss.png','1500137481s2.png','desc',2,2,1,'2017-07-15 11:21:21','2017-07-24 07:18:10'),(9,NULL,'cat3','cat3','cat-group-3','1500123991s3.png','1500137558s3.png','',4,2,1,'2017-07-15 11:22:38','2017-07-24 07:18:23'),(10,NULL,'home-furniture','Home & Furniture','Home & Furniture','1507005434Cleaning.png',NULL,'Group responsible for home jobs and stuffs',0,1,1,'2017-10-03 04:37:14','2017-10-03 04:37:14'),(11,NULL,'','Cleaning ','Home & Furniture','1507005434Cleaning.png','1507005500Supply_hire.png','Home vegetables cutting and cleaning ',10,2,1,'2017-10-03 04:38:20','2017-10-03 04:38:20'),(12,NULL,'','Furniture cleaning ','Home & Furniture','1507005434Cleaning.png','1507005604Waiting_staff.png','clean furniture',10,2,1,'2017-10-03 04:40:04','2017-10-03 04:40:04');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryDashboard`
--

DROP TABLE IF EXISTS `categoryDashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryDashboard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `display_order` int(10) DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryDashboard`
--

LOCK TABLES `categoryDashboard` WRITE;
/*!40000 ALTER TABLE `categoryDashboard` DISABLE KEYS */;
INSERT INTO `categoryDashboard` VALUES (2,'cat2',1,8,'2017-10-03 04:35:53','2017-10-03 04:35:53'),(3,'cat3',1,9,'2017-10-03 04:35:59','2017-10-03 04:35:59'),(4,'Cleaning ',1,11,'2017-10-03 04:39:20','2017-10-03 04:39:20'),(5,'cat1',1,7,'2017-10-28 15:45:27','2017-10-28 15:45:27');
/*!40000 ALTER TABLE `categoryDashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_group`
--

DROP TABLE IF EXISTS `category_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_group` (
  `id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `group_description` varchar(255) NOT NULL,
  `group_image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_group`
--

LOCK TABLES `category_group` WRITE;
/*!40000 ALTER TABLE `category_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_fields`
--

DROP TABLE IF EXISTS `contact_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_fields` (
  `id` int(10) unsigned NOT NULL,
  `contactId` int(10) unsigned DEFAULT NULL,
  `fieldKey` varchar(255) DEFAULT NULL,
  `fieldValue` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_fields`
--

LOCK TABLES `contact_fields` WRITE;
/*!40000 ALTER TABLE `contact_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_groups`
--

DROP TABLE IF EXISTS `contact_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupName` varchar(255) DEFAULT NULL,
  `groupCategory` varchar(255) DEFAULT NULL,
  `contactId` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_groups`
--

LOCK TABLES `contact_groups` WRITE;
/*!40000 ALTER TABLE `contact_groups` DISABLE KEYS */;
INSERT INTO `contact_groups` VALUES (9,'Diwali',NULL,NULL,0,NULL,NULL,NULL,'2017-10-18 00:15:20','2017-10-18 00:15:20'),(11,'Diwali',NULL,3,9,'monika@gmail.com','monika',NULL,'2017-10-18 00:15:20','2017-10-18 00:15:20'),(12,'Diwali',NULL,2,9,'kanikasethi04@gmail.com','kanika',NULL,'2017-10-18 00:15:20','2017-10-18 00:15:20');
/*!40000 ALTER TABLE `contact_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `categoryId` int(10) unsigned DEFAULT NULL,
  `categoryName` text,
  `user_id` int(10) unsigned DEFAULT NULL,
  `address` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'Mr.','','ramesh','','kandy','kroy@gmail.com',NULL,'8103194076',NULL,'1,2',NULL,'Kundan roy ','2017-09-14 12:46:37','2017-10-18 00:11:30'),(2,'mr',NULL,'Suresh',NULL,'kanika','kanikasethi04@gmail.com',NULL,'8109264446',NULL,NULL,NULL,'Kundan roy ','2017-10-03 04:42:00','2017-10-18 00:11:56'),(3,'Mr.','','monika','','monika','monika@gmail.com',NULL,'9826916395',NULL,'Array',NULL,'monika','2017-10-03 04:57:35','2017-10-14 00:59:43'),(4,'Mrs.','','Anandi','Dubey',NULL,'rbsartistry@infowayindia.in',NULL,'7999506748',NULL,'1',NULL,'Indore\r\nmp','2017-10-14 00:58:12','2017-10-14 00:58:12');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_supports`
--

DROP TABLE IF EXISTS `customer_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_supports` (
  `id` int(10) NOT NULL,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_supports`
--

LOCK TABLES `customer_supports` WRITE;
/*!40000 ALTER TABLE `customer_supports` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2017_03_12_221035_create_admin_table',1),('2017_03_12_221035_create_assignments_table',1),('2017_03_12_221035_create_courses_table',1),('2017_03_12_221035_create_password_resets_table',1),('2017_03_12_221035_create_permission_role_table',1),('2017_03_12_221035_create_permissions_table',1),('2017_03_12_221035_create_professor_profiles_table',1),('2017_03_12_221035_create_role_user_table',1),('2017_03_12_221035_create_roles_table',1),('2017_03_12_221035_create_student_courses_table',1),('2017_03_12_221035_create_student_profiles_table',1),('2017_03_12_221035_create_users_table',1),('2017_03_12_221037_add_foreign_keys_to_assignments_table',1),('2017_03_12_221037_add_foreign_keys_to_courses_table',1),('2017_03_12_221037_add_foreign_keys_to_permission_role_table',1),('2017_03_12_221037_add_foreign_keys_to_professor_profiles_table',1),('2017_03_12_221037_add_foreign_keys_to_role_user_table',1),('2017_03_12_221037_add_foreign_keys_to_student_courses_table',1),('2017_03_12_221037_add_foreign_keys_to_student_profiles_table',1),('2017_03_18_071810_add_column_to_courses_table',2),('2017_03_18_072721_add_column_to_assignments_table',2),('2017_03_18_194033_create_syllabus_table',2),('2017_03_26_063346_update_email_to_users_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `page_content` text,
  `creeated_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tasks`
--

DROP TABLE IF EXISTS `post_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locationType` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `typeOfPeople` text COLLATE utf8_unicode_ci,
  `totalAmount` float(10,2) DEFAULT '0.00',
  `paymentMode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hourlyRate` float(10,2) DEFAULT '0.00',
  `totalHours` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `dueDate` date DEFAULT NULL,
  `peopleRequired` int(11) DEFAULT NULL,
  `budget` int(11) DEFAULT NULL,
  `budgetType` mediumtext COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tasks`
--

LOCK TABLES `post_tasks` WRITE;
/*!40000 ALTER TABLE `post_tasks` DISABLE KEYS */;
INSERT INTO `post_tasks` VALUES (1,'test','desc','remote','indore','452001','1',100.00,NULL,5.00,'2',2,'2025-12-17',NULL,100,'abc','open','2017-10-27 20:50:13','2017-10-27 20:50:13'),(2,'test','desc','remote','indore','452001','1',100.00,NULL,5.00,'2',3,'2025-12-17',NULL,100,'abc','open','2017-11-06 06:18:16','2017-11-06 11:18:16'),(3,'clean my bathroom ','hgghfhg','Work remotely','','','',120.00,NULL,0.00,'0',88,NULL,NULL,NULL,'Total','open','2017-10-28 06:09:16','2017-10-28 06:09:16'),(4,'clean my bathroom ','clean my bathroom ','Work remotely','','','',684.00,NULL,57.00,'12',88,NULL,NULL,NULL,'Per Hour','open','2017-10-28 06:55:20','2017-10-28 06:55:20'),(5,'clean my bathroom ','clean my bathroom','Work remotely','','','',100.00,NULL,0.00,'0',88,NULL,NULL,NULL,'Total','open','2017-10-30 05:31:17','2017-10-30 05:31:17'),(6,'adadsasd','dsadasdsa','Work remotely','','','Looking for multiple people',12.00,NULL,0.00,'0',88,NULL,NULL,NULL,'Total','open','2017-10-30 13:12:06','2017-10-30 13:12:06'),(7,'Clean my 1 bedroom service','Clean my 1  bedroom service and 1 bathroom service along with vaccum cleaner','Come to work place','melbourne','452005','Looking for multiple people',1000.00,NULL,0.00,'0',88,NULL,NULL,NULL,'Total','open','2017-10-31 04:27:32','2017-10-31 04:27:32'),(8,'bcvbvc','xcbxc','Work remotely','','','Looking for multiple people',50.00,NULL,5.00,'10',62,NULL,NULL,NULL,'Per Hour','open','2017-11-02 07:17:35','2017-11-02 07:17:35'),(9,'create logo ','please create logos for my firm ','Work remotely','','','Looking for multiple people',50.00,NULL,5.00,'10',62,NULL,NULL,NULL,'Per Hour','open','2017-11-02 07:24:31','2017-11-02 07:24:31'),(10,'clean my bathroom add','clean my bathroom ','Work remotely','','','',16673142.00,NULL,67777.00,'246',70,NULL,NULL,NULL,'Per Hour','open','2017-11-04 12:42:00','2017-11-04 12:42:00'),(11,'sASAs','SasAS','Work remotely','','','',0.00,NULL,0.00,'12',70,NULL,NULL,NULL,'Per Hour','open','2017-11-04 12:52:32','2017-11-04 12:52:32'),(12,'sASAs','SasAS','Work remotely','','','',408.00,NULL,34.00,'12',70,NULL,NULL,NULL,'Per Hour','open','2017-11-04 12:53:35','2017-11-04 12:53:35'),(13,'xzxxz','ZXfsfsdfs','Work remotely','','','',2829.00,NULL,23.00,'123',70,NULL,NULL,NULL,'Per Hour','open','2017-11-04 12:54:43','2017-11-04 12:54:43'),(14,'dsfdsfsdfsf','sdfsdfsdf','Work remotely','','','',12.00,NULL,1.00,'12',70,NULL,NULL,NULL,'Per Hour','open','2017-11-04 12:55:20','2017-11-04 12:55:20'),(15,'adasdad','sadsad','Work remotely','','','',12.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-04 13:01:56','2017-11-04 13:01:56'),(16,'dasdadsdadasd','sadsadasdasd','Work remotely','','','',12.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-04 13:04:13','2017-11-04 13:04:13'),(17,'cxzcxzc','czxczxczxc','Work remotely','','','',12.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-04 13:15:28','2017-11-04 13:15:28'),(18,'ddsdd','sadsadasd','Work remotely','','','',19.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-04 13:15:56','2017-11-04 13:15:56'),(19,'this is good','this is good','Come to work place','','','Looking for one team with multiple people',400.00,NULL,0.00,'0',98,NULL,NULL,NULL,'Total','open','2017-11-06 06:37:32','2017-11-06 06:37:32'),(20,'this is good','this is good','Come to work place','','','Looking for one team with multiple people',400.00,NULL,0.00,'0',98,NULL,NULL,NULL,'Total','open','2017-11-06 06:37:36','2017-11-06 06:37:36'),(21,'this is good','this is good','Come to work place','','','Looking for one team with multiple people',400.00,NULL,0.00,'0',98,NULL,NULL,NULL,'Total','open','2017-11-06 06:37:37','2017-11-06 06:37:37'),(22,'this is good','this is good','Come to work place','','','Looking for one team with multiple people',400.00,NULL,0.00,'0',98,NULL,NULL,NULL,'Total','open','2017-11-06 06:37:39','2017-11-06 06:37:39'),(23,'Cfdg','Gdgdf','Work remotely','','','',100.00,NULL,4.00,'25',99,NULL,NULL,NULL,'Per Hour','open','2017-11-09 10:07:30','2017-11-09 10:07:30'),(24,'dgsdfgs','sgsdfgdfsgfdgfdsg','Work remotely',NULL,NULL,'',40.00,NULL,4.00,'10',62,NULL,NULL,NULL,'Per Hour','open','2017-11-09 11:55:23','2017-11-09 11:55:23'),(25,'dgsdfgs','sgsdfgdfsgfdgfdsg','Work remotely',NULL,NULL,'',40.00,NULL,4.00,'10',62,NULL,NULL,NULL,'Per Hour','open','2017-11-09 11:55:26','2017-11-09 11:55:26'),(26,'Clean my washroom','clean my bedroom ','Work remotely',NULL,NULL,'',234.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:38:23','2017-11-09 22:38:23'),(27,'Clean my washroom','clean my bedroom ','Work remotely',NULL,NULL,'',234.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:38:28','2017-11-09 22:38:28'),(28,'Clean my washroom','clean my bedroom ','Work remotely',NULL,NULL,'',234.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:39:13','2017-11-09 22:39:13'),(29,'clean my washrroom','ddsfsdfsfs','Work remotely',NULL,NULL,NULL,123.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:40:50','2017-11-09 22:40:50'),(30,'Sumit\'s car wash','wash my car ','Work remotely',NULL,NULL,NULL,21.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:43:30','2017-11-09 22:43:30'),(31,'Sumit\'s activa wash','kanika wash my activa ','Work remotely',NULL,NULL,NULL,213.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:46:12','2017-11-09 22:46:12'),(32,'kanika bday decoration','kanika bday decoration ','Work remotely',NULL,NULL,NULL,123.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 22:48:18','2017-11-09 22:48:18'),(33,'kundan bday decoration','kundan bday decoration','Work remotely',NULL,NULL,NULL,24.00,NULL,2.00,'12',70,NULL,NULL,NULL,'Per Hour','open','2017-11-09 22:53:52','2017-11-09 22:53:52'),(34,'ddasd','asdsad','Work remotely',NULL,NULL,NULL,123.00,NULL,0.00,'0',70,NULL,NULL,NULL,'Total','open','2017-11-09 23:17:08','2017-11-09 23:17:08'),(35,'titllllllll','jxjdjdfjdjdjdhd','Work remotely','','','1',255.00,NULL,255.00,'1',99,'2017-11-10',NULL,255,'total','open','2017-11-10 11:28:58','2017-11-10 11:28:58'),(36,'clean room','please clean room','Come to work place','indore','455001','1',50.00,NULL,10.00,'5',35,'2017-11-11',NULL,50,'per hour','open','2017-11-10 11:31:20','2017-11-10 11:31:20'),(37,'clean room','test demo','Work remotely','','','1',100.00,NULL,100.00,'1',36,'2017-11-11',NULL,100,'total','open','2017-11-10 11:33:22','2017-11-10 11:33:22'),(38,'bdbdh','bzbdb','Work remotely','','','1',25.00,NULL,25.00,'1',37,'2017-11-10',NULL,25,'total','open','2017-11-10 11:36:40','2017-11-10 11:36:40'),(39,'new title ','describe m3 ','Work remotely','','','1',10.00,NULL,10.00,'1',99,'2017-11-11',NULL,10,'total','open','2017-11-10 11:45:56','2017-11-10 11:45:56'),(40,'hdhdhs','hshdjdjdjdh','Work remotely','','','1',25.00,NULL,25.00,'1',99,'2017-11-10',NULL,25,'','open','2017-11-10 11:56:58','2017-11-10 11:56:58'),(41,'titlllllllllllllLlllllllllllansnsnsns','bxbdbdbdbdbdbsbsnsns','Come to work place','indoreeeeeeee','373737','1',200.00,NULL,200.00,'1',40,'2017-11-10',NULL,200,'total','open','2017-11-10 11:58:24','2017-11-10 11:58:24'),(42,'cleany room','clean my room','Work remotely','','','1',25.00,NULL,25.00,'1',99,'2017-11-10',NULL,25,'total','open','2017-11-10 12:41:40','2017-11-10 12:41:40'),(43,'demo test today 10nov','tes5 description ','Come to work place','indore','455001','1',40.00,NULL,10.00,'4',99,'2017-11-10',NULL,40,'per hour','open','2017-11-10 12:45:33','2017-11-10 12:45:33'),(44,'tjcnh','hghgj','Work remotely','','','1',5.00,NULL,5.00,'1',99,'2017-11-10',NULL,5,'total','open','2017-11-10 13:15:48','2017-11-10 13:15:48'),(45,'hshdhshshdhd','bdfhdjfjfjhdfjdjdndhdjdjd','Work remotely','','','1',15.00,NULL,15.00,'1',99,'2017-11-10',NULL,15,'total','open','2017-11-10 13:23:38','2017-11-10 13:23:38'),(46,'dgshdjx','gkgksjsjdh','Work remotely','','','1',10.00,NULL,NULL,'1',99,'2017-11-10',NULL,10,'total','open','2017-11-10 13:52:46','2017-11-10 13:52:46'),(47,'dzhzbxbxjxjx','fjcnzjzkzkzjdjxjcvsyvsjz','Work remotely','','','1',20.00,NULL,10.00,'2',99,'2017-11-10',NULL,20,'per hour','open','2017-11-10 13:54:28','2017-11-10 13:54:28'),(48,'dhcj','gjgjg','Work remotely','','','1',55.00,NULL,NULL,NULL,99,'2017-11-10',NULL,55,'total','open','2017-11-10 14:00:56','2017-11-10 14:00:56'),(49,'wash my car','washy car','Work remotely','','','1',258.00,NULL,NULL,NULL,70,'2017-11-12',NULL,258,'total','open','2017-11-11 01:39:33','2017-11-11 01:39:33'),(50,'website design','i want to design my new website. any one is expert on that so please contact me','Come to work place','367 gjjjvfuk dhjj djkn','452001','1',250.00,NULL,250.00,'1',104,'2017-11-12',NULL,250,'','open','2017-11-11 17:24:25','2017-11-11 17:24:25'),(51,'fhf','dufjcjcjv','Work remotely','','','1',15.00,NULL,NULL,NULL,99,'2017-11-22',NULL,15,'total','open','2017-11-11 17:32:32','2017-11-11 17:32:32'),(52,'dgsg','dsggdf','Work remotely','','','1',10.00,NULL,5.00,'2',99,'2017-11-12',NULL,10,'per hour','open','2017-11-12 13:34:21','2017-11-12 13:34:21'),(53,'hsndksbxjs','he.disnxnzkskxbxnskkdx\n','Work remotely','','','1',500.00,NULL,NULL,NULL,94,'2017-11-20',NULL,500,'total','open','2017-11-13 12:01:29','2017-11-13 12:01:29');
/*!40000 ALTER TABLE `post_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL,
  `product_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_category` int(10) unsigned DEFAULT NULL,
  `product_sub_category` int(10) unsigned DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `qty` int(10) unsigned DEFAULT '1',
  `discount` float(10,2) NOT NULL DEFAULT '0.00',
  `description` mediumtext COLLATE utf8_unicode_ci,
  `photo` mediumtext COLLATE utf8_unicode_ci,
  `product_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validity` int(10) unsigned DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `total_stocks` int(10) unsigned DEFAULT NULL,
  `available_stocks` int(10) unsigned DEFAULT NULL,
  `views` int(10) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programms`
--

DROP TABLE IF EXISTS `programms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) DEFAULT NULL,
  `description` text,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `target_users` varchar(255) DEFAULT NULL,
  `complete_task` int(10) DEFAULT NULL,
  `reward_point` float DEFAULT NULL,
  `created_by` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programms`
--

LOCK TABLES `programms` WRITE;
/*!40000 ALTER TABLE `programms` DISABLE KEYS */;
INSERT INTO `programms` VALUES (1,'Program','dfdsfds','02/10/2017','11/10/2017','last_15_days',0,0,NULL,'2017-09-25 18:30:00','2017-10-01 16:38:34'),(3,'program1','desc','01/10/2017','30/10/2017','last_30_days',1,2,NULL,'2017-10-01 10:30:23','2017-10-01 10:30:42'),(4,'Xmas targeting ','kanika','30/10/2017','31/12/2017','last_30_days',5,67,NULL,'2017-10-03 05:08:34','2017-10-03 05:09:24'),(5,'kanika bday','fffffffffffffffff','19/10/2017','21/10/2017','last_15_days',0,0,NULL,'2017-10-13 21:17:56','2017-10-13 21:17:56'),(6,'program','hii','19/10/2017','21/10/2017','last_15_days',5,1,NULL,'2017-10-13 21:18:50','2017-10-13 21:18:50');
/*!40000 ALTER TABLE `programms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','admin','admin',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL,
  `field_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `support_type` varchar(255) DEFAULT NULL,
  `subject` tinytext,
  `description` text,
  `ticket_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `coupan_id` int(11) unsigned DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_price` float(10,2) DEFAULT NULL,
  `discount_price` float(10,2) DEFAULT '0.00',
  `transaction_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (54,NULL,NULL,NULL,'55534432432','1','mannu@malinator.com','$2y$10$1dq3jUagpFzmKVUYtGZji.GmJtv.4zkKH75soxpM/rAYnyz/ZfXru',NULL,0,'2017-07-11 14:49:49','2017-07-16 12:27:54'),(55,NULL,NULL,NULL,'5434543','1','kanika@mailinator.com','$2y$10$.zHabm9kdOecC9S9w6JW3.bZERT/wXoxDv44f9Y0PJcUO0hANxiNi',NULL,1,'2017-07-11 15:34:06','2017-09-14 12:42:08'),(61,NULL,NULL,NULL,'8103194076','1','kroy.iips@gmail.com','$2y$10$Ofh/6PdwNuxGJCDKB5tRvui0xqInlW1nxHimg9whvC7KnzomyBQ86',NULL,1,'2017-07-16 12:26:54','2017-07-16 12:27:50'),(62,'k','r',NULL,NULL,'','shashi.shrivas@gmail.com','$2y$10$mRGfVcw95tbb0WMG/vCD8OP6a77kBSgNBd8Wm/jQ3YaEci.YZ92YG',NULL,0,'2017-09-28 12:08:10','2017-09-28 12:08:10'),(63,NULL,NULL,NULL,NULL,'','demo@gmail.com','$2y$10$dr9a/OGxCpCK8eDIOfqPXeLfWnINHJiKT1kKc2N3XtjvD829xk9LS',NULL,0,'2017-09-30 05:39:06','2017-09-30 05:39:06'),(64,NULL,NULL,NULL,NULL,'','demon@gmail.com','$2y$10$j9QrJIWmeKLdIayaTCUyRuhCzFYLrY9N7/V.3UNdKrtP5a2hWQPeW',NULL,0,'2017-09-30 06:16:19','2017-09-30 06:16:19'),(65,NULL,NULL,NULL,NULL,'','demon1@gmail.com','$2y$10$Ka0jdbOAaoRb515KpDJBEehLJ/XxVvZ65HSHWMwinCazG75DZi6cO',NULL,0,'2017-09-30 08:17:39','2017-09-30 08:17:39'),(66,NULL,NULL,NULL,NULL,'','adb@gmail.com','$2y$10$gsgFZOZz7bySfazkKJ8MaOa1TfHnEmZ9WIApyvfPZDHFLnpV21eje',NULL,0,'2017-09-30 08:48:39','2017-09-30 08:48:39'),(67,NULL,NULL,NULL,NULL,'','vaibhav@gmail.com','$2y$10$PIRmc3VuM2hbSCzLHWrPf.a4rFtBLSWcmxLerPqXbe9ALwIpsJ9vW',NULL,0,'2017-09-30 10:20:02','2017-09-30 10:20:02'),(68,NULL,NULL,NULL,NULL,'','sonal@gmail.com','$2y$10$vmfC.zlB79fhubBDksNvLe.LI6it3TjQR49a805fBhzIOIjorCk7a',NULL,0,'2017-10-01 18:20:39','2017-10-01 18:20:39'),(70,NULL,NULL,NULL,'7000838317','1','kanikasethi04@gmail.com','$2y$10$vMGp.Q61Iay8L2Ufa7drIeDpRXKM2nvISchGO8hV2h73nJE1EP9eG',NULL,0,'2017-10-03 04:22:11','2017-11-08 07:17:52'),(71,NULL,NULL,NULL,NULL,'','ad@gmail.com','$2y$10$jHMkKXy8pG8B36DzdgYj/eTI/4gRnlaGbnQmkJ2PgL9zMrBc7TW9e',NULL,0,'2017-10-04 07:44:03','2017-10-04 07:44:03'),(72,NULL,NULL,NULL,NULL,'','ad@qgmail.com','$2y$10$hqHA5VOyUa6.khqcjNhCLOlfsXjdWROsFHjLBaHDr1csqhZibxEaG',NULL,0,'2017-10-04 07:46:16','2017-10-04 07:46:16'),(73,NULL,NULL,NULL,NULL,'','abcd@gmail.com','$2y$10$X0JZSF8opUIC9n6Oo3/apuVAWV8c1DqV4F0lTFwAnE5YyvXRDXSmG',NULL,0,'2017-10-04 07:49:49','2017-10-04 07:49:49'),(74,NULL,NULL,NULL,NULL,'','abcd@qgmail.com','$2y$10$c2/UxkSlKWcPd7rhI5c3BuqIqc/8SCFk79IFXPRrzNdNwpMNPjc1O',NULL,0,'2017-10-04 07:50:22','2017-10-04 07:50:22'),(75,NULL,NULL,NULL,NULL,'','abcd@qgmahil.com','$2y$10$8KWJVAoErr8cPqYxX494v.uiTHOeb2y9Y1qCDh9DuG9VwBvHdlJZ.',NULL,0,'2017-10-04 07:50:52','2017-10-04 07:50:52'),(76,NULL,NULL,NULL,NULL,'','jai@gamail.com','$2y$10$wui27/CMZwfnb0nntxcg8eZog7WvV7Hl8k2XyB.zWBvAFw3zJ.4Bq',NULL,0,'2017-10-04 07:55:55','2017-10-12 18:56:52'),(77,NULL,NULL,NULL,NULL,'','mohitsethi@gmail.com','$2y$10$FoMHcTem7UEI335mqzeYWuNEV.KWyLHPG5qvPVujCR488GtWHAyC6',NULL,0,'2017-10-04 19:29:57','2017-10-12 18:56:50'),(78,NULL,NULL,NULL,'8982461354','1','myweblink2016@gmail.com','$2y$10$EpC4d8HYddl2QZhjaowNseRo7euIRDdnk39SrbLJ67yDaDvpH0yGi',NULL,0,'2017-10-05 14:37:01','2017-10-12 18:56:47'),(79,NULL,NULL,NULL,NULL,'','vicky@gmail.com','$2y$10$70biXVSiUadnuJugdeiGyO8nwtpo8wo0OWOXFo8mKOJV1DsalxA5a',NULL,1,'2017-10-08 14:45:51','2017-10-12 18:57:33'),(80,'bsh','xhd',NULL,NULL,'','s@gmail.com','$2y$10$JtO3jDwfs.cIMdzGHLhCO.z0pnLEeJiMzFLH.oadfak3BDF63lO5y',NULL,1,'2017-10-09 17:14:52','2017-10-09 17:14:52'),(81,'sha','sh',NULL,NULL,'','ss@gmail.com','$2y$10$owIx4h.pD0oFVj4xctTdXOEP3m0pBZUT3nZwMJ28UdElvUZNMGVAm',NULL,1,'2017-10-09 17:21:35','2017-10-09 17:21:35'),(82,'shs','hsn',NULL,NULL,'','ews@gmail.com','$2y$10$6YoD.O.AvvYmsEJMoiZEiuN7WxDDw2n0dBQas0/RRAervAqgxLwUG',NULL,1,'2017-10-09 17:37:10','2017-10-09 17:37:10'),(83,'resh','jack',NULL,NULL,'','reshkshanaa13@gmail.com','$2y$10$HNV9zJ.nMaOp/DNPUhnBBuPV68rUv0XW4SEEE6NvdEPW7nl45pv1W',NULL,1,'2017-10-10 07:40:45','2017-10-10 07:40:45'),(84,NULL,NULL,NULL,'8109264446','1','harish@admin.com','$2y$10$aQUh4mMb/cE3RLIv7lL3.OJ4EjOGb3cC5jVN9tv4ThvgtTnAKdn5S',NULL,1,'2017-10-12 19:02:29','2017-10-12 19:02:29'),(85,'mohit','sethi',NULL,NULL,'','mohit@gmail.com','$2y$10$zEJiOP.08toNpWrAX0m4Ne2v5HP0CShIumbxIhlYpzacrEnoDZot6',NULL,1,'2017-10-14 09:18:15','2017-10-14 09:18:15'),(86,'sumit','yadav',NULL,NULL,'','sumit@gmail.com','$2y$10$mBpjk8cfOdm0QQEjOS4J4.RMEiUBXstUXuUIoKXVgaGyNtpDlJ6aW',NULL,1,'2017-10-14 09:20:54','2017-10-14 09:20:54'),(87,'rama','sethi',NULL,NULL,'','rama@gmail.com','$2y$10$1LUkjH1Hm6zhBh2kFg7p3OCly.YrBPcvKwgq2q8HsTtID/Lj1gBUq',NULL,1,'2017-10-14 09:45:50','2017-10-14 09:45:50'),(88,'kanika','',NULL,NULL,'','kanika@gmail.com','$2y$10$Q94Lo6iSm2CdFRusQ4lK3OuYuqlMZu6gSn25ZqRwROuKCOPmDZXO6',NULL,1,'2017-10-14 10:05:54','2017-10-14 10:05:54'),(89,'kanika','sethi',NULL,NULL,'','kanikasethi0427@gmail.com','$2y$10$r08B3cPJMfPAaHpFVCFsO.SImKPp0x2k1SGOdKBGLej6HzViQpC4a',NULL,1,'2017-10-14 10:06:58','2017-10-14 10:06:58'),(90,'monika','yadav',NULL,NULL,'','monika@gmail.com','$2y$10$KQLQi/wapE1OmxmK2I0Qie02fuCALmB./wUfHjwYWiduSTnmdUsX.',NULL,1,'2017-10-14 11:03:19','2017-10-14 11:03:19'),(91,'kanika','sethi',NULL,NULL,'','kanika44427@mailinator.com','$2y$10$ivpIlANYTl/Pysucm3s7FOTcgY6QntqOND7l0jmPI13fxBk07g7fC',NULL,1,'2017-10-14 11:05:54','2017-10-14 11:05:54'),(92,'test','test',NULL,NULL,'','test@t.com','$2y$10$4t.nvjhNJ9UeP66TjQ3feulEr7qcqU33kQu6L5D38l/3szSA4EE/6',NULL,1,'2017-10-16 08:32:33','2017-10-16 08:32:33'),(93,'sumit','yadav',NULL,NULL,'','sumityadav@gmail.com','$2y$10$afpKrADdWjiDE3gjKZzFiOgDPTvxgFXjg6zHc2lQ1dnyxpaKtf2qu',NULL,1,'2017-10-16 19:15:44','2017-10-16 19:15:44'),(94,'test','test1',NULL,NULL,'','test@test.com','$2y$10$H.VVQZ5z53EE1x.TBY/IxOJDo9VM7W/VD3KgvsDLGjjN4vjLZsz1C',NULL,1,'2017-10-29 11:37:21','2017-10-29 11:37:21'),(95,'Sumit','',NULL,NULL,'','sumit44427@gmail.com','$2y$10$MlKgAGZYkN4EzFNXdroos.gm9XPiAQKk32E56vnA6D8pKQHxPr99i',NULL,1,'2017-11-01 19:01:15','2017-11-01 19:01:15'),(96,'dfsdfsdfsd','fsdfsdfsdf',NULL,NULL,'','fsdfsdfsd@gmal.com','$2y$10$snzflq.ypkC7smKs8AxOmeDCR64/atg9xa90VOKL6k1dCc/fDybZa',NULL,1,'2017-11-04 14:45:38','2017-11-04 14:45:38'),(97,'kanika','sethi',NULL,NULL,'','kanika678@gmail.com','$2y$10$uYCOMdCjUlPPdtgS.NlFLO51NsDg7war8D2rdAIqo9zll1QbibdMi',NULL,1,'2017-11-04 15:24:06','2017-11-04 15:24:06'),(98,'murali','valayutham',NULL,NULL,'','murali.valayutham@yahoo.com','$2y$10$sqRxqjbjUKtyjIjVr2xbkOQinaWSrxXV4LJMIfWlyqadgzMGFqS/6',NULL,1,'2017-11-06 06:31:05','2017-11-06 06:31:05'),(99,'test','demo',NULL,NULL,'','aj@gmail.com','$2y$10$.4Ycs4caL0Baxrg226.D/e/RcI8qNrbQVzjIIdAUNWeuoQ2kK3yOm',NULL,1,'2017-11-07 16:14:55','2017-11-07 16:14:55'),(100,'some','test',NULL,NULL,'','test1@test.com','$2y$10$JhyWf06E/ctz8/vivk/BxOR.55594DzB1OwclfeNvMHjS1gG2lCwG',NULL,1,'2017-11-08 14:47:57','2017-11-08 14:47:57'),(101,'Arpan','Gupta',NULL,NULL,'','arpan.gupta@mailinator.com','$2y$10$eFApV1iQ4H68Zr0k6q3VxufhjCxvJyHPjlRdK/Mpi7wpZU6KEakUy',NULL,1,'2017-11-09 23:40:23','2017-11-09 23:40:23'),(102,'Arpan','Gupta',NULL,NULL,'','arpangupta@mailinator.com','$2y$10$jHy7vt.zUa0JWc8BAuSPMuKuYIYLVbSd9YQLEkMNMDNjmFWgjrNPW',NULL,1,'2017-11-11 17:05:37','2017-11-11 17:05:37'),(103,'Arpan','Gupta',NULL,NULL,'','arpangupta1@mailinator.com','$2y$10$M4lW424a25PExfiou9AzNelCgh7CJ2Ikp/zYXVs0pYH9lXpZQnWEm',NULL,1,'2017-11-11 17:07:17','2017-11-11 17:07:17'),(104,'vaibhav','kasar',NULL,NULL,'','vaibhavdeveloper2014@gmail.com','$2y$10$bHk38l0/Xau2cOuEfD7bv.M8rc7oVtj9/l0CGINWW5s1aOkYcLNEO',NULL,1,'2017-11-11 17:22:01','2017-11-11 17:22:01'),(105,'shubhan','chawda',NULL,NULL,'','chawdas@gmail.com','$2y$10$HkQpqBF2moaUczRAM.0B7uKNVLxXH81cZvpKFkcxQ7d4DEMNlGi5i',NULL,1,'2017-11-13 12:48:35','2017-11-13 12:48:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yt_tasks`
--

DROP TABLE IF EXISTS `yt_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yt_tasks` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `people_required` int(11) NOT NULL,
  `budget` int(11) NOT NULL,
  `budget_type` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yt_tasks`
--

LOCK TABLES `yt_tasks` WRITE;
/*!40000 ALTER TABLE `yt_tasks` DISABLE KEYS */;
INSERT INTO `yt_tasks` VALUES (1,'Need servicing of refrigerator','I need a picture frame picked up from Sunshine North and delivered to Belmont. Will fit in back seat or boot.Can anyone do this today. I will have this ready about 10.30am.',23,'2017-07-25',2,250,'Hourly','2017-07-24 18:50:10','2017-07-24 18:50:10');
/*!40000 ALTER TABLE `yt_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ytasker'
--

--
-- Dumping routines for database 'ytasker'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-13 12:00:09
