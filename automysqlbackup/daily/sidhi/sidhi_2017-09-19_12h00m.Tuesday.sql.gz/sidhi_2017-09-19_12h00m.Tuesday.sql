-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: sidhi
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sidhi`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sidhi` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sidhi`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@admin.com','$2y$10$Ss0If0b4QNwyvogBOgW6gO5d96e9qFK4oaG7Tx2ZzV7WmpMKpoZy6','jHFOWgc9sYrMacnPaPomv7vMNGV6rparNg3dtIe5zvS2XCZvWZc6DmGaOAu1',NULL,'2017-07-22 16:13:25','pavan kumar'),(5,'info@siddhisanskriti.com','$2y$10$G8ILTi8Gmte4Te51RNAj2OiQ2zI5H3SNUfypMHV/MYoAe7J1v8XJ2','Vr2I0EKXSkTNRxZfmVsKeDTiUw4GkyQJGwPDD9EDub8xmYWEjm4yuTgJ30rm','2017-03-19 10:22:04','2017-07-27 06:44:20','');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `photo` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(10) unsigned DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (49,'Sarees','sarees','Sarees','Sarees',0,1,NULL,'2017-04-03 15:50:03','2017-06-26 14:33:46'),(52,'Luxury Watches','luxury-watches','Luxury Watches','Luxury Watches',50,2,NULL,'2017-04-03 15:51:18','2017-04-06 04:23:59'),(57,'Banarsi Sarees','banarsi-sarees','Banarsi Sarees','Banarsi Sarees',0,1,NULL,'2017-04-04 16:35:57','2017-06-26 14:34:27'),(64,'Television','television','Television','Television',56,2,NULL,'2017-04-05 14:26:42','2017-04-06 04:24:23'),(65,'Designer Sarees','designer-sarees','Designer Sarees','Designer Sarees',0,1,1,'2017-06-26 14:34:45','2017-06-26 14:34:45'),(66,'Printed Sarees','printed-sarees','Printed Sarees','Printed Sarees',0,1,1,'2017-06-26 14:35:14','2017-06-26 14:35:14'),(67,'Printed Cotton Kurti','printed-cotton-kurti','Printed Cotton Kurti','Printed Cotton Kurti',0,1,1,'2017-06-26 15:09:54','2017-06-26 15:09:54'),(68,'Georget sari','georget-sari','Georget sari','Georget sari',0,1,1,'2017-06-26 20:56:03','2017-06-26 20:56:03'),(69,'Cotton Silk Sarees','cotton-silk-sarees','Cotton Silk Sarees','Cotton Silk Sarees',0,1,1,'2017-06-26 20:58:26','2017-06-26 20:58:26');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Mobile','mobile',0,'2017-03-29 14:56:22','2017-03-29 14:56:22'),(2,'Samsung','samsung',1,'2017-03-29 14:56:28','2017-03-29 14:56:28'),(3,'Iphone','iphone',1,'2017-03-29 14:56:40','2017-03-29 14:56:40'),(4,'Iphone 7','iphone-7',3,'2017-03-29 14:56:48','2017-03-29 14:56:48'),(5,'Galaxy J7','galaxy-j7',2,'2017-03-29 14:58:16','2017-03-29 14:58:16'),(11,'Comics','comics',9,'2017-04-03 14:52:18','2017-04-03 14:52:18'),(7,'Mobile','mobile',0,'2017-03-29 15:20:09','2017-03-29 15:20:09'),(8,'Pets','pets',0,'2017-03-29 15:20:41','2017-03-29 15:20:41'),(9,'Books','books',0,'2017-04-03 14:32:58','2017-04-03 14:32:58'),(10,'Books','books',0,'2017-04-03 14:34:09','2017-04-03 14:34:09'),(12,'Comics','comics',9,'2017-04-03 14:52:29','2017-04-03 14:52:29');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupans`
--

DROP TABLE IF EXISTS `coupans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coupan_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `start_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupans`
--

LOCK TABLES `coupans` WRITE;
/*!40000 ALTER TABLE `coupans` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_supports`
--

DROP TABLE IF EXISTS `customer_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_supports` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_supports`
--

LOCK TABLES `customer_supports` WRITE;
/*!40000 ALTER TABLE `customer_supports` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dealers`
--

DROP TABLE IF EXISTS `dealers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dealer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dealer_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dealers`
--

LOCK TABLES `dealers` WRITE;
/*!40000 ALTER TABLE `dealers` DISABLE KEYS */;
/*!40000 ALTER TABLE `dealers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_100000_create_password_resets_table',1),('2017_03_19_212358_create_admin_table',1),('2017_03_19_212358_create_categories_table',1),('2017_03_19_212358_create_products_table',1),('2017_03_19_212358_create_users_table',1),('2017_03_19_212400_add_foreign_keys_to_products_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `banner_image1` varchar(255) DEFAULT NULL,
  `page_content` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'aboutUS','149281268603.jpg','<p>aboutUS</p>\r\n','2017-04-21 16:31:14','2017-04-21 16:41:26'),(2,'T&C','149281290301.jpg','<p>T&amp;C</p>\r\n','2017-04-21 16:45:03','2017-04-21 16:45:03');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_keys`
--

DROP TABLE IF EXISTS `product_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `secret_key` text COLLATE utf8_unicode_ci,
  `user_id` int(10) unsigned DEFAULT NULL,
  `validity_year` int(10) unsigned DEFAULT NULL,
  `dealer_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_keys`
--

LOCK TABLES `product_keys` WRITE;
/*!40000 ALTER TABLE `product_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_category` int(10) unsigned DEFAULT NULL,
  `product_sub_category` int(10) unsigned DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `qty` int(10) unsigned DEFAULT '1',
  `discount` float(10,2) NOT NULL DEFAULT '0.00',
  `description` mediumtext COLLATE utf8_unicode_ci,
  `photo` mediumtext COLLATE utf8_unicode_ci,
  `product_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validity` int(10) unsigned DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `total_stocks` int(10) unsigned DEFAULT NULL,
  `available_stocks` int(10) unsigned DEFAULT NULL,
  `views` int(10) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_category` (`product_category`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`product_category`) REFERENCES `categories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (12,'Saree',65,NULL,1350.00,1,0.00,'<p>Designer Georgette saree with BP</p>\r\n','1501139336WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHED (7).jpeg',NULL,NULL,NULL,NULL,NULL,30,'2017-06-22 15:24:40','2017-08-05 17:52:35'),(13,'Designer Saree',65,NULL,2500.00,1,15.00,'<p>Designer Saree</p>\r\n','1498511082d.jpg',NULL,NULL,NULL,NULL,NULL,21,'2017-06-22 15:25:39','2017-08-06 01:05:57'),(14,'Sarees',65,NULL,1350.00,1,0.00,'<p>Designer Georgette saree with BP</p>\r\n','1501139289WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHED (6).jpeg',NULL,NULL,NULL,NULL,NULL,27,'2017-06-22 15:57:05','2017-08-06 01:06:17'),(15,'Saree',65,NULL,1350.00,1,0.00,'<p>Designer Georgette saree with BP</p>\r\n','1501139259WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHED (5).jpeg',NULL,NULL,NULL,NULL,NULL,9,'2017-06-26 21:07:56','2017-08-06 08:30:31'),(16,'Saree',65,NULL,1350.00,1,0.00,'<p>Designer Georgette saree with BP</p>\r\n','1501139227WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHED (4).jpeg',NULL,NULL,NULL,NULL,NULL,20,'2017-06-26 21:09:41','2017-08-06 08:30:27'),(17,'Saree',65,NULL,1350.00,1,0.00,'<p>Designer Georgette saree with BP</p>\r\n','1501139151WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHED (3).jpeg',NULL,NULL,NULL,NULL,NULL,14,'2017-06-26 21:11:11','2017-08-06 01:06:00'),(18,'Saree',65,NULL,1350.00,1,0.00,'<p>Designer saree with BP</p>\r\n','1501138863WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHED (2).jpeg',NULL,NULL,NULL,NULL,NULL,16,'2017-06-26 21:12:01','2017-08-06 01:06:10'),(19,'Saree',65,NULL,1350.00,1,0.00,'<p>Designer Georgette saree with BP</p>\r\n','1501138733WhatsApp Image 2017-07-20 at 1.23.43 PM CODE1800 RATE1250 LACE BORDER GEOR HALF BLOUSE UNSTITCHE.jpeg',NULL,NULL,NULL,NULL,NULL,4,'2017-07-27 06:55:37','2017-08-06 01:06:03');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (44,'website_title','Siddhisanskriti : India  largest online cloth center','2017-04-15 17:31:06','2017-06-26 21:16:59'),(45,'website_email','info@siddhisanskriti.com','2017-04-15 17:31:07','2017-06-15 13:39:12'),(46,'website_url','http://siddhisanskriti.com/','2017-04-15 17:31:07','2017-06-15 13:39:13'),(47,'contact_number','+91-9062828453','2017-04-15 17:31:07','2017-06-26 15:01:10'),(48,'company_address','<p>KOLKATA</p>\r\n','2017-04-15 17:31:07','2017-06-26 15:01:10'),(49,'banner_image1','1498508912ss.jpg','2017-04-15 17:31:07','2017-06-26 14:58:32'),(53,'_method','PATCH','2017-04-15 18:06:33','2017-04-15 18:06:33'),(54,'banner_image2','1498508658Twitter-Banner.jpg','2017-04-20 12:49:23','2017-06-26 14:54:18'),(55,'banner_image3','1498508575banner1.jpg','2017-04-20 12:49:23','2017-06-26 14:52:55');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_billing_addresses`
--

DROP TABLE IF EXISTS `shipping_billing_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_billing_addresses` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address1` text,
  `address2` text,
  `zip_code` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `address_type` tinyint(4) DEFAULT '1',
  `payment_mode` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_billing_addresses`
--

LOCK TABLES `shipping_billing_addresses` WRITE;
/*!40000 ALTER TABLE `shipping_billing_addresses` DISABLE KEYS */;
INSERT INTO `shipping_billing_addresses` VALUES (1,11,NULL,NULL,NULL,' nileshvyas1986@gmail.com','admin@admin.com','343543543',NULL,'dfgdfgfdgfd',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 10:23:08','2017-04-10 10:40:56'),(2,11,NULL,NULL,NULL,' nileshvyas1986@gmail.com','admin@admin.com','256   ',NULL,'mp','mp','452001','kad@gmail.com','123456',NULL,2,NULL,'2017-04-10 10:37:01','2017-04-10 11:29:12'),(3,0,NULL,NULL,NULL,'nileshvyas1986@gmail.com','admin@admin.com',' ',NULL,'',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 12:56:40','2017-04-10 13:01:02'),(4,16,NULL,NULL,NULL,'kundn','kroy.webxpert@gmail.com','456123',NULL,'indore',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 13:39:17','2017-04-10 13:39:17'),(5,16,NULL,NULL,NULL,'kandu','kanu@sdfdk.cso','45421212',NULL,'indore sds','dgdfgfdg','89089','indore','mp',NULL,2,NULL,'2017-04-10 13:39:41','2017-04-10 13:39:41'),(6,15,NULL,NULL,NULL,'nileshvyas1986@gmail.com','kroy.iips@gmail.com',' 456123 ',NULL,'4',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 16:31:26','2017-04-14 16:02:37'),(7,15,NULL,NULL,NULL,'nileshvyas1986@gmail.com','admin@admin.com',' 456123 ',NULL,'4','fsdfds','34324324','kad2@gmail.com','kad2@gmail.com',NULL,2,NULL,'2017-04-10 16:31:50','2017-04-14 16:02:40'),(8,18,NULL,NULL,NULL,'vaibhav','v@gmail.com','8794564',NULL,'indore',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 16:54:45','2017-04-10 16:54:46'),(9,18,NULL,NULL,NULL,'va','v@gmail.com','789546465',NULL,'iuh','hkjh','4545415','root','root',NULL,2,NULL,'2017-04-10 16:55:23','2017-04-10 16:55:23'),(10,19,NULL,NULL,NULL,'kundan','kroy.iips@gmail.com','8103194076',NULL,'indore mp 452001',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-13 14:52:34','2017-04-13 14:52:34'),(11,19,NULL,NULL,NULL,'kundan roy','kroy.zend@gmail.com','8103194076',NULL,'indore','vijay nagar mp','452001','indore','mp',NULL,2,NULL,'2017-04-13 14:53:15','2017-04-13 14:53:15');
/*!40000 ALTER TABLE `shipping_billing_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `support_type` varchar(255) DEFAULT NULL,
  `subject` tinytext,
  `description` text,
  `ticket_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `coupan_id` int(11) unsigned DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_price` float(10,2) DEFAULT NULL,
  `discount_price` float(10,2) DEFAULT '0.00',
  `transaction_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,1,NULL,1,'cod',1,1,'10%',1000.00,900.00,'1111','Samsung phone','2017-04-05 18:30:00',NULL),(2,16,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,0.00,NULL,NULL,'2017-04-10 14:02:57','2017-04-10 14:02:57'),(3,16,8,'men shitrs',NULL,'COD',NULL,NULL,NULL,300.00,0.00,NULL,NULL,'2017-04-10 14:02:57','2017-04-10 14:02:57'),(4,16,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,NULL,'[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-05 21:51:51\"}]','2017-04-10 14:06:51','2017-04-10 14:06:51'),(5,16,8,'men shitrs',NULL,'COD',NULL,NULL,NULL,300.00,300.00,NULL,'[{\"id\":8,\"product_title\":\"men shitrs\",\"product_category\":58,\"product_sub_category\":null,\"price\":300,\"qty\":1,\"discount\":0,\"description\":\"<p>men<\\/p>\\r\\n\",\"photo\":\"1491429261men.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-05 21:54:21\",\"updated_at\":\"2017-04-05 21:54:21\"}]','2017-04-10 14:06:52','2017-04-10 14:06:52'),(6,16,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,NULL,'[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-05 21:51:51\"}]','2017-04-10 14:07:40','2017-04-10 14:07:40'),(7,16,8,'men shitrs',NULL,'COD',NULL,NULL,NULL,300.00,300.00,NULL,'[{\"id\":8,\"product_title\":\"men shitrs\",\"product_category\":58,\"product_sub_category\":null,\"price\":300,\"qty\":1,\"discount\":0,\"description\":\"<p>men<\\/p>\\r\\n\",\"photo\":\"1491429261men.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-05 21:54:21\",\"updated_at\":\"2017-04-05 21:54:21\"}]','2017-04-10 14:07:41','2017-04-10 14:07:41'),(8,15,2,'laptop',NULL,'COD',NULL,NULL,NULL,10000.00,10000.00,NULL,'[{\"id\":2,\"product_title\":\"laptop\",\"product_category\":53,\"product_sub_category\":null,\"price\":10000,\"qty\":1,\"discount\":0,\"description\":\"<p>laptop<\\/p>\\r\\n\",\"photo\":\"1491341650lap.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-04 21:24:53\",\"updated_at\":\"2017-04-05 22:25:07\"}]','2017-04-10 16:31:55','2017-04-10 16:31:55'),(9,15,11,'watch1',NULL,'COD',NULL,NULL,NULL,2222.00,2222.00,NULL,'[{\"id\":11,\"product_title\":\"watch1\",\"product_category\":52,\"product_sub_category\":null,\"price\":2222,\"qty\":1,\"discount\":10,\"description\":\"<p>watch1<\\/p>\\r\\n\\r\\n<p>watch1<\\/p>\\r\\n\\r\\n<p>watch1watch1<\\/p>\\r\\n\\r\\n<p>watch1<\\/p>\\r\\n\",\"photo\":\"1491595760tredy.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-07 20:09:20\",\"updated_at\":\"2017-04-07 20:09:20\"}]','2017-04-10 16:41:57','2017-04-10 16:41:57'),(10,18,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,NULL,'[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-05 21:51:51\"}]','2017-04-10 16:56:08','2017-04-10 16:56:08'),(11,19,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492115004','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-05 21:51:51\"}]','2017-04-13 14:53:24','2017-04-13 14:53:24'),(12,19,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492117689','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-05 21:51:51\"}]','2017-04-13 15:38:09','2017-04-13 15:38:09'),(13,19,5,'casual shoes',NULL,'COD',NULL,NULL,NULL,500.00,500.00,'1492117973','[{\"id\":5,\"product_title\":\"casual shoes\",\"product_category\":62,\"product_sub_category\":null,\"price\":500,\"qty\":1,\"discount\":0,\"description\":\"<p>casual shoes<\\/p>\\r\\n\",\"photo\":\"1491429133casual.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":32,\"created_at\":\"2017-04-05 21:52:13\",\"updated_at\":\"2017-04-13 21:12:45\"}]','2017-04-13 15:42:53','2017-04-13 15:42:53'),(14,19,2,'laptop',NULL,'COD',NULL,NULL,NULL,10000.00,10000.00,'1492117973','[{\"id\":2,\"product_title\":\"laptop\",\"product_category\":53,\"product_sub_category\":null,\"price\":10000,\"qty\":1,\"discount\":0,\"description\":\"<p>laptop<\\/p>\\r\\n\",\"photo\":\"1491341650lap.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:24:53\",\"updated_at\":\"2017-04-12 20:44:41\"}]','2017-04-13 15:42:53','2017-04-13 15:42:53'),(15,19,5,'casual shoes',NULL,'COD',NULL,NULL,NULL,500.00,500.00,'1492118244','[{\"id\":5,\"product_title\":\"casual shoes\",\"product_category\":62,\"product_sub_category\":null,\"price\":500,\"qty\":1,\"discount\":0,\"description\":\"<p>casual shoes<\\/p>\\r\\n\",\"photo\":\"1491429133casual.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":35,\"created_at\":\"2017-04-05 21:52:13\",\"updated_at\":\"2017-04-13 21:14:09\"}]','2017-04-13 15:47:24','2017-04-13 15:47:24'),(16,19,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492118631','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":10,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-12 20:43:06\"}]','2017-04-13 15:53:51','2017-04-13 15:53:51'),(17,19,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492118695','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":10,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-12 20:43:06\"}]','2017-04-13 15:54:55','2017-04-13 15:54:55'),(18,19,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492120052','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":10,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-12 20:43:06\"}]','2017-04-13 16:17:32','2017-04-13 16:17:32'),(19,19,2,'laptop',NULL,'COD',NULL,NULL,NULL,10000.00,10000.00,'1492120052','[{\"id\":2,\"product_title\":\"laptop\",\"product_category\":53,\"product_sub_category\":null,\"price\":10000,\"qty\":1,\"discount\":0,\"description\":\"<p>laptop<\\/p>\\r\\n\",\"photo\":\"1491341650lap.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:24:53\",\"updated_at\":\"2017-04-12 20:44:41\"}]','2017-04-13 16:17:32','2017-04-13 16:17:32'),(20,19,3,'television',NULL,'COD',NULL,NULL,NULL,10000.00,10000.00,'1492120052','[{\"id\":3,\"product_title\":\"television\",\"product_category\":64,\"product_sub_category\":null,\"price\":10000,\"qty\":1,\"discount\":20,\"description\":\"<p>television<\\/p>\\r\\n\",\"photo\":\"1491428972tele.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-05 21:49:32\",\"updated_at\":\"2017-04-05 21:49:32\"}]','2017-04-13 16:17:32','2017-04-13 16:17:32'),(21,19,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492120616','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":10,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-12 20:43:06\"}]','2017-04-13 16:26:56','2017-04-13 16:26:56'),(22,19,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492120628','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":10,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-12 20:43:06\"}]','2017-04-13 16:27:08','2017-04-13 16:27:08'),(23,19,8,'men shitrs',NULL,'COD',NULL,NULL,NULL,300.00,300.00,'1492120783','[{\"id\":8,\"product_title\":\"men shitrs\",\"product_category\":58,\"product_sub_category\":null,\"price\":300,\"qty\":1,\"discount\":0,\"description\":\"<p>men<\\/p>\\r\\n\",\"photo\":\"1491429261men.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":1,\"created_at\":\"2017-04-05 21:54:21\",\"updated_at\":\"2017-04-05 21:54:21\"}]','2017-04-13 16:29:43','2017-04-13 16:29:43'),(24,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492204457','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-14 21:14:04\"}]','2017-04-14 15:44:17','2017-04-14 15:44:17'),(25,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492204565','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-14 21:14:04\"}]','2017-04-14 15:46:05','2017-04-14 15:46:05'),(26,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492204858','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-14 21:14:04\"}]','2017-04-14 15:50:58','2017-04-14 15:50:58'),(27,15,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492205562','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":13,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-14 21:32:18\"}]','2017-04-14 16:02:42','2017-04-14 16:02:42'),(28,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492205765','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-14 21:14:04\"}]','2017-04-14 16:06:05','2017-04-14 16:06:05'),(29,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492205824','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-14 21:14:04\"}]','2017-04-14 16:07:04','2017-04-14 16:07:04'),(30,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492205992','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-14 21:14:04\"}]','2017-04-14 16:09:52','2017-04-14 16:09:52'),(31,15,7,'trendy watch',NULL,'COD',NULL,NULL,NULL,6000.00,6000.00,'1492206367','[{\"id\":7,\"product_title\":\"trendy watch\",\"product_category\":63,\"product_sub_category\":null,\"price\":6000,\"qty\":1,\"discount\":0,\"description\":\"<p>trendy watch<\\/p>\\r\\n\",\"photo\":\"1491429195tredy.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-05 21:53:15\",\"updated_at\":\"2017-04-12 20:55:18\"}]','2017-04-14 16:16:07','2017-04-14 16:16:07'),(32,15,7,'trendy watch',NULL,'COD',NULL,NULL,NULL,6000.00,6000.00,'1492206407','[{\"id\":7,\"product_title\":\"trendy watch\",\"product_category\":63,\"product_sub_category\":null,\"price\":6000,\"qty\":1,\"discount\":0,\"description\":\"<p>trendy watch<\\/p>\\r\\n\",\"photo\":\"1491429195tredy.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":4,\"created_at\":\"2017-04-05 21:53:15\",\"updated_at\":\"2017-04-12 20:55:18\"}]','2017-04-14 16:16:47','2017-04-14 16:16:47'),(33,15,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492211291','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":16,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-14 22:32:16\"}]','2017-04-14 17:38:11','2017-04-14 17:38:11'),(34,15,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492211309','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":16,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-14 22:32:16\"}]','2017-04-14 17:38:29','2017-04-14 17:38:29'),(35,19,5,'casual shoes',NULL,'COD',NULL,NULL,NULL,500.00,500.00,'1492284189','[{\"id\":5,\"product_title\":\"casual shoes\",\"product_category\":62,\"product_sub_category\":null,\"price\":500,\"qty\":1,\"discount\":0,\"description\":\"<p>casual shoes<\\/p>\\r\\n\",\"photo\":\"1491429133casual.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":35,\"created_at\":\"2017-04-05 21:52:13\",\"updated_at\":\"2017-04-13 21:14:09\"}]','2017-04-15 13:53:09','2017-04-15 13:53:09'),(36,19,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492284189','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":9,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-15 19:22:55\"}]','2017-04-15 13:53:09','2017-04-15 13:53:09'),(37,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492801463','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":12,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-20 20:51:38\"}]','2017-04-21 13:34:23','2017-04-21 13:34:23'),(38,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492805373','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":14,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-21 20:09:27\"}]','2017-04-21 14:39:33','2017-04-21 14:39:33'),(39,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492805462','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":16,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-21 20:10:55\"}]','2017-04-21 14:41:02','2017-04-21 14:41:02'),(40,15,5,'casual shoes',NULL,'COD',NULL,NULL,NULL,500.00,500.00,'1492805960','[{\"id\":5,\"product_title\":\"casual shoes\",\"product_category\":62,\"product_sub_category\":null,\"price\":500,\"qty\":1,\"discount\":0,\"description\":\"<p>casual shoes<\\/p>\\r\\n\",\"photo\":\"1491429133casual.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":40,\"created_at\":\"2017-04-05 21:52:13\",\"updated_at\":\"2017-04-21 20:18:15\"}]','2017-04-21 14:49:20','2017-04-21 14:49:20'),(41,15,5,'casual shoes',NULL,'COD',NULL,NULL,NULL,500.00,500.00,'1492806508','[{\"id\":5,\"product_title\":\"casual shoes\",\"product_category\":62,\"product_sub_category\":null,\"price\":500,\"qty\":1,\"discount\":0,\"description\":\"<p>casual shoes<\\/p>\\r\\n\",\"photo\":\"1491429133casual.jpg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":42,\"created_at\":\"2017-04-05 21:52:13\",\"updated_at\":\"2017-04-21 20:28:19\"}]','2017-04-21 14:58:28','2017-04-21 14:58:28'),(42,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492951190','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":18,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-23 12:39:05\"}]','2017-04-23 07:09:50','2017-04-23 07:09:50'),(43,15,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492951190','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":23,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-23 12:39:32\"}]','2017-04-23 07:09:50','2017-04-23 07:09:50'),(44,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1492951194','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":18,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-23 12:39:05\"}]','2017-04-23 07:09:54','2017-04-23 07:09:54'),(45,15,6,'Luxury Watches',NULL,'COD',NULL,NULL,NULL,1000.00,1000.00,'1492951194','[{\"id\":6,\"product_title\":\"Luxury Watches\",\"product_category\":52,\"product_sub_category\":null,\"price\":1000,\"qty\":1,\"discount\":0,\"description\":\"<p><a href=\\\"http:\\/\\/localhost\\/quikr\\/product-category\\/Watch\\/luxury-watches\\/52\\\">Luxury Watches<\\/a><\\/p>\\r\\n\",\"photo\":\"1491429172lux.jpeg\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":23,\"created_at\":\"2017-04-05 21:52:52\",\"updated_at\":\"2017-04-23 12:39:32\"}]','2017-04-23 07:09:54','2017-04-23 07:09:54'),(46,15,1,'sport shoes',NULL,'COD',NULL,NULL,NULL,11500.00,11500.00,'1493242530','[{\"id\":1,\"product_title\":\"sport shoes\",\"product_category\":51,\"product_sub_category\":null,\"price\":11500,\"qty\":1,\"discount\":0,\"description\":\"<p>sport shoes<\\/p>\\r\\n\",\"photo\":\"1491429111casual sooes.JPG\",\"product_type\":null,\"validity\":null,\"product_key_id\":null,\"total_stocks\":null,\"available_stocks\":null,\"views\":23,\"created_at\":\"2017-04-04 21:02:39\",\"updated_at\":\"2017-04-26 21:35:06\"}]','2017-04-26 16:05:30','2017-04-26 16:05:30');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sidhi'
--

--
-- Dumping routines for database 'sidhi'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-19 12:00:11
