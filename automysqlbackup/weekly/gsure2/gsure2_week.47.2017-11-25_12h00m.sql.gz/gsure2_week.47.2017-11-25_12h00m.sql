-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: gsure2
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `gsure2`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `gsure2` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `gsure2`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@admin.com','$2y$10$G8ILTi8Gmte4Te51RNAj2OiQ2zI5H3SNUfypMHV/MYoAe7J1v8XJ2','P4ZnFf6bewIsKUPC4e329uCGhNsJs84jfqfQsT1DMbX9lMItd7LeKfNBvPxy',NULL,'2017-07-05 19:48:02','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_data_fields`
--

DROP TABLE IF EXISTS `common_data_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_data_fields` (
  `id` int(10) unsigned NOT NULL,
  `field_key` varchar(255) DEFAULT NULL,
  `field_value` text,
  `method` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `route` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_data_fields`
--

LOCK TABLES `common_data_fields` WRITE;
/*!40000 ALTER TABLE `common_data_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_data_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` text,
  `email` text,
  `phone` varchar(255) DEFAULT NULL,
  `subject` text,
  `message` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
INSERT INTO `contact_us` VALUES (0,'kanika','kanikasethi04@gmail.com',NULL,'query for angular','need tutorial for anguar','2017-07-01 23:38:47','2017-07-01 23:38:47'),(0,'kanika','kanikasethi04@gmail.com',NULL,'query for angular','need tutorial for anguar','2017-07-01 23:41:48','2017-07-01 23:41:48'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','Interested in angularjs.','2017-07-04 03:01:55','2017-07-04 03:01:55'),(0,'vaibhav','vaibhavdeveloper2014@gmail.com',NULL,'bhgjk','cfdhdh','2017-07-05 19:17:11','2017-07-05 19:17:11'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','angualrjs','2017-07-09 10:10:57','2017-07-09 10:10:57'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','angualrjs','2017-07-09 10:10:58','2017-07-09 10:10:58'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','angualrjs','2017-07-09 10:10:59','2017-07-09 10:10:59'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','angualrjs','2017-07-09 10:10:59','2017-07-09 10:10:59'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','angualrjs','2017-07-09 10:11:00','2017-07-09 10:11:00'),(0,'kanika','kanikasethi04@gmail.com',NULL,'angularjs','angualrjs','2017-07-09 10:11:00','2017-07-09 10:11:00'),(0,'test','tt@mailinator.com',NULL,'test-mail','testing-email','2017-07-19 08:48:17','2017-07-19 08:48:17');
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `main_course` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_course` text COLLATE utf8_unicode_ci,
  `parent_id` int(10) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `image` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `general_info` text COLLATE utf8_unicode_ci,
  `course_prerequisites` text COLLATE utf8_unicode_ci,
  `course_duration` int(11) DEFAULT NULL,
  `training_highlights` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (77,'javascript courses',NULL,0,NULL,NULL,'2017-07-29 09:22:13','2017-07-29 09:22:13',NULL,NULL,NULL,NULL),(78,'javascript courses','angularjs',77,'AngularJS is a very powerful JavaScript Framework. It is used in Single Page Application (SPA) projects. It extends HTML DOM with additional attributes and makes it more responsive to user actions. AngularJS is open source, completely free, and used by thousands of developers around the world. It is licensed under the Apache license version 2.0.','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAMAAAC8EZcfAAABKVBMVEX///+oDgDgFgCzs7Py8vIAAADENC329vb8/PyytbXOzs75+fmoCwATExOyt7fKysqUlJRgYGDs7Oyurq7z+/tRUVHn5+e9vb0sLCzY2NjExMTe3t42NjbhIhPm39+bm5saGhrsp6SAgICwHh3x4eC2rayMjIytKCAUFBSpGQtERESwvr9aWlqsIhhra2vx1tatXVi6n57aKiDuvLrjQDiqLia1WFS+q6qtSERKSkqxk5IiIiLtsK16enrWOzPvysjTRDzPUk3Cf3yvdHHKZmOrNi+9k5Gxg4HNsa7PqKetZmLBhIG7PTnHcm7cKBurPznmXlfrlpHnaWTZw8LEX1bXk43ZoZ7isa3SfnfUQzvCT0/Nc2rDKiHRTkfqgX3RnZrndXHmYl3qjogA+JIVAAAMQUlEQVR4nO2cfVvaSBvFgUmakAxBgxJCUKlrwIhQURGUWre+YXXVvtjdtrvttvv9P8Rzz1sIkKC7F6le15PzjyIQftwzc+ZkMjGVSpQoUaJEiRIlSpTo/0OqbmqWZurqY4OES1c0CxFZtqI/NsyEdNOxCkioULbNp8Somk6ekRkNQ0DmHfOJNLXk8KY1Go32oB1g1BzzseFSiqADPPf49fazTu/EbRhZjmhpjvSIdGpR0GUN4/zLq6VM5i+MvU5vUDD8Mlp5R3kcPFPQAV779NVNhui1l8bAWN8bIFFFwlj82d1RlWxRO4S615+XMkxLb5ppEMZpr751AM8O2/onDhlVccq83xlu9+qroAN9045xmgl+di4PXBToj8rPYFSVom8pqHt+t50J6sh2vfRQGJ+dHLjGkNHWY7ZHpTi0FPf89FVmVO9NG13i9Ahi+hYY/XFdKDvxWbhi2r6loPPrXzMTermgZbvpEUI6ZnonB2joPfFYuGoWRccDP75+vT2Jl3m7BoBoaxSQMTaBcWjhMdijnUeFgB+H0IHeLSgaMg7wBCFlrPdO2o3GsDvOFtDihoeuXr9aCsfL7L4ggFm0FwJIEdPA6AoLL88WkDavcX66exNBRzxmQQJA1BiEAvLuWO8NXIqozRYQKuMeR9aOFfCIAUaVUIzqdHPLhYaecRPbUL6Inif0fkGigKhxko4mJJBnpIbObAEdZLTHXW9UNzsCMGvdTge8JRPkjJNYERluiPEF9Bb4GOB9JcS9BrxoxhFHgXn/9VTAnSFg1upMBdwjgLPlS6lQl7tpfLuS5AOixuU0vvQlAFoznkx0CzVOpwE+XwgAZlFzykD2TgAwP+MZWS+jxvW0AprBCqLG1pQKNgcwiLUZV1DVUONqig2+k0YAketFlhDX28bMbTCl2qgxxQhvXigM8G9xFrAXXcEO8ekZ2yAzwt1IwG+shReOvnY5YTca8IwM4pmfkBIjjHbqowUG+P3ZnohUvcgZ+TYGG4TTc4gykU793qQtvLC2/ZfHS5htR3bCvVgAFRiaX6MAd3gB/8k8Yx9PhklkCS+hyNbsAcEIv0TwQZKmI8R8m3mGPZdlUuM8HBB7xGVmbYPMCKOc+jkv4MslqCDmJcy64ZEBewcx2CAAghEehxvhZ15A6XuGAHZ4CSOCK252Z58GU9QIjavwOP0PL+DRNgXEW6yERngJcZM8OXMbpEYY7tRwKiKGCAHkeZSmrlDADnm2OHtAMMJuKOB3zvdilwGm8SUvYfcsjLBnxOHTqZQJ/T7MqW+ESb/MCMBbUcLLMEBi5dkYVg0BsBEG+JbxKeYPAZjGJ6KEYcGV2mAMgBIYYUimXuImrRxlhoB+CcPO7wYwiMsxrGkq5dBM/ZnxSdK3IWAanzNAoz0ZXL0DclIcwwKSng+NrM9ZzpLWboKAt8ILJ+c7z0Vx2GCKnLsbk07Nk7QkvcsEAAMlnAiucdkgO3efAORJWpJ2RwFvXb4UdjtewTMUjw3CKCkY7fGp5GZNAK4x5V0ungpRe4wP92IERGjcqb9Jo/LPSYYaM2u8RYJELBd4itBgY4BLRwv3Ao6lLnyC4rFBaoTjmfq7qdwHmHVHzRoPUDw2SI3QGHPqnbEChlUwO5q6cBv+lo/legQYoTEaWX+YDwA0xkpIhs+MFy+FwAhHnZonaUlZ8KVlA+KEwdSF6wBYiMUGiRFmr4J8v66JpPrc1wU4TJdLWGE7UEIIiwAY01VaB1wt6NTvRI55n1kS+q3eFPLE+Z0RSF24V4jLBimgGwD0k/ROwL5J5BeiazAE8KDuEzIbjAkQjDDo1DxJSwvfMkHAoCfz87vG8NoOs8GYmti0EBpG1u2jYNQPBTzr8hKe+6kLx5UGicAI0XBx4Yco4PNMBKCfrAOpC5OT4nJMl2VVAPQjq5+k135EA/ZEshYlxB7pl/l4+FKpPEK+Ef4qCniUiQbE56KEPDLgTjeGxUtfME34RvhSTCL/RAOyMUt74YAFVxa1YwO0IZsIjxFz29ruNMA0dxpkMLPGe7GsrgqBEXY5yDsRY15mpgCm8bGY7wbs8WWMNkiNkDv1tp+k304FTDddcYG4zsZ1Nj4bpEbIl4HfiXDwYmk6IJw9cdHUhQexLF4KKQDIIuvzHdBL0PvMdMD02QFVu31A+2ScNghGCIDTL9hNAuK053kQHep1Tyxezvhae1BghBGLmJGAw/AAv3mXpEvG5tPgM5CVzqfWcBIwQNo7zxLXic0GqRFmG+jq838AxPh24LI9H7HZIJzYkV1RhuEeR14UiwLEHbHfw3Li3B2l0t09BuqeRnTFcEDa+She1o59gxndHpVF7fCuGAIIY2Ovzc6gsnEsu02I7UbOGudhV8YmbQZ7twds25aV/1nbRU26Qc8wjieXhCdmkvTZgO81ysc2BYeI7XBsuNfjiGNpBncuCwyvHOPYDZPukHY2Gu3T7UhAjJtbbeYs5ViHbrgkm7ZzY9S4nwVbd+9AOMvj7FU22S4edP41BBDmjQPEWtd+tK3UOnNFw716NQ6IzwYuG7ua9Kg75llXzLrXNwFA6HwnLnO+8qNv6Fe0LDXu7t0SBwTn2+J41k/f4B0mKc8XsciG6mcwrfXawlmeAh5RMV+gfRFizl/e7YDPG/HPug+Xyo0bXd+dsKFraY95F0SIJJt2xQbfGa89/o0kE2KumGWz7hNq3aFUvhPcKj6l25lGRCbop+EskVKebvUSJUqUKFGiUakzXGac5bF8lStiqVsNTK/Dmx9VRRIPAmvi9KUTN5AXS8NlBUUnCgQK//CBIz5A+mKuwI/emhdLonph02K/5edam4ubrVpZTUmr8+LjlcMW/JqfnxsjrMmr4hUr81StQ3G7hvTnn2vk59HH0y9f7k4//bH2MEBbludZZbSqXOHxXV+Va4y5Kuf6pVJVrkopsySLFiyW5HJKRfLG6HUGqS9XeMJWNuVcdb1azcm5Q0a4XPdeQPU+/oK9zlmnmcYfHwZ4KPdzeQEot/jhV+U58oGLcnVOKxYdrbCqE0CxiaNYgveoBXlxFLAg9+UVzjovrzi2bZfn5ZzFAX8BwA/Y+3uZ6OL4jwfxmev7NfmQA66v8+MzQHVO3uCxT1Vo2aYD6hv9udy+IgDpvUIqvKs2BFT38O+soOoDb59dkZFdYl1bq1Zqcj8/BDRzshV46b2Amrzq7PN6kQpyat4vKaDUIWX8F5IqfVVqsWNp1Y1iS94wfcAxgPsA9ZZsK3NySx0BdKqslAzQ7HgPa1mhLGleK0cHB1RQLVZoezPAQ972DwR01vf1lNOv2gFAVduX58UgAUBlD9+9+BfnMvqmbNNWQBwwZa3LBQ6obtKR8lBA6LHEr1pyTRWAytx8Llfj45r1wYsmrt+dnoLLPKgLarlFOJpSyC0yQCWl12QoAQXUA4COo94HaJZKJplL+uQHA9RkedNfcWWjWL/oNT3PS2Pv7gE+qK5C6VZqtVaOfDQFTJmb8oaq0wq2fNu1S+B499gMglej1dphnxaSAjoV4Vs+YEo3lz+Arur40/2AxWrJBKMmggPZFDBlV+RVc44Urya6Tyqf60ujgOvaGKBeyWlQY6INnQPqhZzwRR+Ql2bh73T9fsACfGmngAqolquaAlBHuVyhRgAtuW8HAPWKLG6DdHLwzCigJm+mJHJz90ofZhk+SMAg1sWXGgGEh03vXj6pwueQlLQBbuowQNIBS4sEsLjBPQP6KgFsyfP8nUjeN0cBVWEr/GUKewyNvMGnz2WvHux1y94v9wJa8ib/ABiBFdXu81xjLkI7kZkE5eRD6uH59RJ8DJR2hQJbFfp0AYomVMxVxOUbK5dzBKBq5bhXrX3EX+DwCjeZtWN8dx+fuj/sIA5MyD4gjAkKmNJXqnKpVVuZ25ShC5AGkxfh0XxVnpcoYGm1RrS6otaGnmluwO8ckDQHGTTSp9+wtwPvedP58unj77/Dw+a9U4om+186pUC7IB9QLawzh1HK86zfV1vELcy5Cn1UKkj0VbJQxa7m/N2g6orcl8Cj2Lc39+VSMXWBvb0jqJ16cdakl+a96/unPNsK5F/HKmt5f4+BVLZY9FMlp1xYKZSLDF0vkkfi3404/P+kZC1LswKzdtFCqqrxTTOqbcHXWf6wzPxQKdofLt68+bD8SP/5JVGiRIkSJUqUKFGiRIkSJUr0H/U/G3ZjaZguyncAAAAASUVORK5CYII=','2017-07-29 09:22:13','2017-07-31 10:15:45','{\"course_prerequisites\":[\"Knowledge of HTML \\/ CSS is required.\",\"Candidate should have a good knowledge of JavaScript and Object Oriented JavaScript.\"],\"training_highlights\":[\"Trainers are Professional Graphics designers from the Industry.\",\"We cover entire course on one or more real time web site project.\",\"Provide Interview tips and assist in resume formation.\"],\"chapter_name\":[\"JavaScript\",\"Introduction\",\"Variables\",\"Operators and Comparisons\",\"Conditional Statements and Loops\",\"User Defined Functions\",\"JS Objects & JS Validations\",\"Sample\",\"test\",\"kill\"]}',NULL,120,NULL),(79,'javascript courses','reactjs',77,'react is a javascript framework','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEUiIiIA2P8A2v8A3v8jAAAA3P8A3/8iIB8A4f8iHh0iHBojCgAjGhcjBgAjCAAjFRAjFxMjEAYiGhcA0/kjDgAWfJAeQ0sSlK0Pp8QaanoLtdUgLjEHxegbW2ghJygfOT8Jvd4Fyu4dS1UVh54aZnUYdokRnLcNr84dTlggMzcSl7AcVWEhKy4ViqEfP0YbYnGSezmOAAAZk0lEQVR4nO1dV4OqOhCWJBCKNLGgooKuvf3/f3fBlUzowRXvefB7O2cVmWQyfSa93hdffPHFF1988cUXX3zxxRdffCEK2sEjNV3XO3hu6/fQXYNYA90hxHD7b3ohzRmS4Xy8PoyPNnH19zz0NVDXOVz9yEsQ+NfF3Pj7++iuvZruQs9DsowkbzZZ2/Y73vUVUKM3iVQso1/IWJXCyeFPi665ZD0JsJI8U4rxeGowIs773roFHDrB+PEeDAhh1TutifMau/bJbeKpuWfGT1W8u/k/nEjjHGGpBAjL4VR32z/QcRczuUDe85m+o72fhHqQafnLPF5Ija7EbbfqDpmGqlz1RAmH9odJNDdqJYGPRZcmtAWNA/IT1D5QwgH9KIluzQ6mNHojR1BAUOsQKg3Pk/DsBc5/GfpKzrzQU/LlaFSjOxFZd9vxcZE/fwU09x/KxOycMAY3hDdCsiLH6lBRsFwQgup+NWx6lka2KC+yEh3hBWEYeCr3UHXd/wRxCdyRAszjnRbHy/KyWmz2Xl57SLK0serVo3uc5VWOjCN/e1vaQ8tenn3EFhMFL2qh1qCOl74TUiea0dcopVrfNu3zycvJQ6SGddtIyVbKfkFWpN3CtRztQQzVyThgO6xuP2TduJt0CxG6E25Z6cAl931Op8l4Q6qW3qH7rASVlXBKjAH/mQFhRwJFLVXQqyBsC5Wtlf9j31rtpAyNSNlfyoWqtfAyJ1DG+7NR+KjWi9jvTT9ivvXvavpGPin5u2ZdJnLmzbF3KKxEwqGb7EqoszMZFD/Xc84pz8izsh98O6z9k2uQXOEXUuOyy8h/pG4KhmW/t1f5jyhBOX0xiJ8+TF1+gE3pRXquPN6V7MzzQ2Sd1eGKP8jKVHucMWtjoWtXcqC2StcCbz4ga4BJ0a1GEehWVkriYM6/nHVG3F9jBj0Oa3aHzOSUTT+g9Y1dyqRh/aGw6Z7fRlk6G+xvZKRm/rStN36c6XO/kXfpnk1JKtnwqIFjqDX1+I1C2+eSUHICkyHxG44NJiddpidDXVSc1feBXlJdoY4bnXl7HnLSBCm/mpESP/O/V6vRemVsiq+d29+DRcow0aCZYTRy5TlV3Rm0p9kzbgdlby1wtNzr81flfaV0exfsEfstoUNvLnhOVXxz4IScEMXhXESJD85qehA7p3C4a8kv9jHgKFL2NOAoVndDobgVnT8dKeTNuxY1JjsRohaURnyORN5qRXhUabLm4ATPr8mHruOnTJQKCJonYvOs1INH0t1o/vbzZ8PnE7o3TUnqd6stnDVzWhKEkaWbuFyEw9Gko/4MKxX0Shsj2D14eRLlSEjGPGFvnpyOJx2rCzpPhVrUysy3b17W08XBpY3uBhHuC3P2a9BuKYUNNlse/XlmF+VQayUxnOlTh3auEF+mMN5FjkLktcxu9BeMwo5t78Grv0T5+Fzy9XYLpI3VdPM7doJfXUtq7rMhQ/XU6k1f5522eJVC4itSFuqmzav+8xRm3aWnNN02RosBn6NQH7/yS7HDWyAwttkO4sr7cxS+9EvuFAhEEKZHaCwcph+k8bbO4xivaPz+GjIscnCLgMRIOHT2OW1B9ZRCSZRCbQC6HkkXl8tbiYt+Fqnp3gUmKcOpgi/HK0IkjZ2efQYSlZ3gjnzOaoOQvmhwlvMOkbxIzObhFlSjshV74c9Z3j2SuqLqWsjuMrlMnDr9JcfcqED0QcjDcE8f857MNKYv5oraCxCjmOl4soN9lZYieWL2s8KhhZdh+G0WUz+ClMFcHsecMRLl0BZgd4P5+J0HTNmBkHcCJokJUkYOOEq4jJmkCFiodPD8PEK3rksywFETUL1kxw4h8nr8qw04naFMG7mBzqU01tZ59kk/pxHhoPFA2D8gUVBOorhTOIpo3rQvYCx6nWcQ6TFdTakpcqmvJLZPakErkCsjXw6b2AEU/geSTxZTiA2RS2pD7FeZFJeegMdY9ucM3Emb0/9HQEi4oTKCUwml1hl1Qdrge/2zrFYS/I9gurdhOe07HELvYg9iOIDkn+6aSRsk1RdSQxz63Hl2redsmaipZK2kvObC2dvT23kRYwpI/nlebUCX7Imu0SoqKQvUycfuM6ScWCsR3LRvu5ahX463GRd48hBWisDIg4/g63o1p4bp2v2iYIWUXvCBwi/KlDXmzQttYBuEmMfFaOKHkYcztVFVdYf8/2NVlaJwfxr93IaEGPaAIxQ8i0/k8TlR81sYQQf2kLirxcifRaqq4N/C7wqaapEUi8tYUVVvthstVi4Z2r/9CGCVdp8C7mXysaZuG+78PNqFnqRguVCc+CoehEpeuBuNe5brUOayKfdPlCf2709TLLYvxiM/kH7L9d9EHEfmo1DfCyfT+ZK53QKZ9b+DOqygRn4Q93basnTGbMuUSrX4fic05gR/DOnvybvuKdRdchxFrShEKWQO7D9bUSrv12T4rt6jcvLMwzUotnxUExfLRVXyoigIE/gM++SfQRB5sVqJxa84iaq3Wwysboikrn2YRBUtH0ATF/GNRdFiPV7NL1RzY10ZKzkGK/mna9Pl5bhaH0Z8fU2DQI6lj+ffNePd9QrUIfNroNSQlwi+eD+80J9xrq2ha0mJdKU1lpRP6wM+HOfvA6wqtQIsFnDRbk1Egh+i0IbONKxmTpRoaS/YX6er2Bpx2bsJ5wgp9bjvELJMNGyEa+hMiNxczDdtpG6tJl5JQ8TzpxTk7SfT8cU13aQ3yUjNj6S4RzSkYk8Zn6pT+2ElmXS12PiRVNLk8Hw8lvyz9YbAW5+MfVS9fcFpOh7GtKXdns4d3nUrbmGZ3Lo8H5VU/xvkeN/sC2UcsLqzn7827vXJeabWnH15RhyeVVhMrGVNNu0xfsSZ0Bvtu3XqN2bWqfuHA6kZ51lZv46MmQ5WtczjjTTaEH9g1SbsB00qSM4WWzFvLen7K9KKcLB1X9xHaq32SoG++IzL/vTGCq8zoQztCN0fo3YBFYis5kIeLESDvMMuKpF3SA3u5BWZYy9PhX7Ah5y+E8thnJNNdlkzeM2WKSL9xvhUzcRPbfZTOzJ89NAWm0zVcN26yVQzp17e1Ih17e6sW4n/wiLfSOIKr50fEDN1Ve6l4Bjc44I2+jp9Jl70E7NqOJ5EBXaV8Ym2Y1V3nmvXifldnU2p9fRe9HG6WcqWPZnaTMzg9iYyZWFKCXN9eByTPiWK7lpnv2BbYe8uWsnZe/RboSyDIsWbHPkGZmBTEJn8Lmjt5ZvzA9FHEDZGxJgU+H5guaMgJyOQ6mui7rGu+dl60FhejQbDjGhkjj5CqczULhDhfanJjMApZss2SJMIuTgitZO+6FwxYHQQk27ZsuWHrPqx8jpHH7PjkbaxmH6jmKG6Y9tOv2IYhH5jx0tdPHkfujui/Lf6ZO1nZSGShWqOh4sMh8ZyqtRucFM2TYsy9ANsYamY0VwyP/+MRtuf9aC8Y59j8zQVZ6ESJmVLQlZ+rr/KNxu1sLXNnGEcTYv9cg8KN4x9ftPdwGO4rPxgYNyuoRRb0xgrsrffLo2SYCsIG2X0MPmcbcoq6rl01axxtgVVmfUahDgZ8V+Qlc2g4kRRFh36XV3nXirs00+Twz72vVi8RVakSa9ottpTeMjD5WIKtrJ8Ryf3iH9lHCxrSbRGmW6W2bFkpdO1YD/+oIhlFmJrpvDq9mWftx5ia35TbHaCflE8MZIKrJTimkCpQyb8uZK9OhKNLUegjLZ1XcospRfbIE7PBrsyKFjCw0XBepAeDWuFQugBHGZ80ThliOqsXGsc8FGCoLr2wb5z+42DW63spRrLloSE82HVe/7cmlXjCXB0zGswTiD7Jh1GRa1bhoF14gwUHFZxnn7kqurUXZM1ywS5JK8Jk4LFVOFwW1KY+PywlOcouoRNPAyBTX4abDJy57odcWn3buKKQc5WRLPoB6YSdzaEIfKZYfteE0qTg7zxAxoj3reQHfXKUA/7mWMEJFY439YVCifwVKShjKlE6cpeK7989FLlopcvN+3BYrHqsDJlmMeAQscYQseSoxgb00yYK2uRAATLeUlMlhUfTfY1WxhDyfOfDUzNNkUV8aY1rpS8NAsHGhvJU6EICzUKobCHjOfRP1cewueP5RUddQtRC8GACLWg0goXk1Ss+DdRaIKuj7HL7Q+S85rCmhWjIFkURkE49/yilLxuOYkDJklKSphZtUML3w68xPSreb0MQZZKoCDPMCTM+UWBaNGsPocAUr6kAQ448ur6xnPvkt2hYmafqewa4HybX3+R/ZIiXmFiT7O2JP9Uxhq4ucqMwfnJbBGe5G0EkURccYpAduFalbKBgolyCoZVybRKQnJxC6nM5NZWlUUKgGJtOri9pbtRhz54zDnW4MoP2tQCgA9V+lXWJVWHkmI8CIFLgqqCgXFNvmSLtOiy50ANztCTCuags20+hmVzEngB1bIHDJpNswXhNO0YyEQHBcDiNaW7DzZBHYVSsc4Jppm0bW2200XNFaVRPaWw5eCJ+KTBixa4yd4IUCihceGLDhOnLXtVuTrNXNsCM51Ru3538BLLahXF9rCkxZ7AQZQXrUpooHwqV1jIFf+1eiCnDkokhjMVkjSFqEfmHLZr5YI6zVxjBhscJJ/aJBz6XLNBiWbWzyJ7WORDKyNL2xxEypgx3y0BEV6vzTytjNmJonyMkC5rXafnmhb6fPpnfutb9XJB4BznlIzOfAClhULUx5k9UgoxqLyJWYZigDxnDOIWDQjstBUK7Wmf/amhXJdHzrkouuICoqboUubtUixu1AxZQKzYHzU8MYdaWMUyHcPeJb//9NhY9VRstyv4FsKGaR+8eLWw8bQH6durIIn2KCcqi2aNtWv0D/NujrMo+IeCE770JVQRlGwTx3F4KsYWRc+hsInavIFNi/67G+afKqj1Na79AZcIYA28R4SFxqroh0JEpchQxrVWJaKCdwgungQsJ+Lk6zaEosrjiS6EgBCeCqwahAXQrjpAYNaKU3WUW0sKPbV4AfnE5hXvLyEpWBV9NEBIJ9N/mh6ppf1BsUa7pAIFofye8A16BeCCLgRTPuZfWLhGj8de8fHSn/KDq/W4d1FPTRNyQRPgBfTHFI+4c6uUpzjMx52pBiUZZ3sNeZqG7G4m5l3d7+dwbeWSEl4aun5YQDgg2oULAeXPjLMqS8w88pmFwLrFLZXJ57dqJxrpZMLnLWrUHdcyl6SpFlbNY/UDK8eI7VFgLhQWlru/zFd2PJ6PR4WYFxeWVmNDAKJHtT25wxs/IE0O6lIA1jaTP9yV539/H5uaCA+nmRqQfCqGsjSy9XLDsGQ1HBfFB3hNj0QylMnVBIX7ZJPJHwZ67fHK5oCTIpWqj7O4h+wnlrHN8tGlw/hsc5RUbCWn4NFlIM/OJbktPpH8UDtDFo1UKzxzjZwzs85xWE9gLNy3fL0RwvtVeTIOGEj9dVEtpqgLof1fGu3DJLnTAUmetx+trDINB4nkp/3PTS4tTQLT4dzP1Jwo+yYCY52xyJRUyWhil/lTLByWOr6cq4jLMj+POn93vh7fLsQqH5LPjWBOHTE2pw0FRblHXXsi8UKsTHaVINYsmW9h6dor0MjG/IERDyFAeVY9nFbXK8ulOKuKKTQul54vxtCM5TVb25tkPZvp6xUm/CYj8q9LI7vqUAYip7MVgKMkpULj1oNwJUfpm0K2IRd30a35xMtmz7EnWBNVnNKc7ONpTviTA5oKwijmDgJkL3REQLhawuBvWFAUBaeb2mSdr82OObTXojwxqW7I0ajuF0M33UjWH89H2KB2IWbd9jNWSGllIwQf0nZHOrB62zBfm42lnxa1iTEG9iRXFxdr6Oi6eha4sSBa7KHDc7mSe7xqW1/K1UHzMVtOJT7YVB8659xI9McG+PO2B4Oa6zBviKBYjW0NEgtCJlXksKJGuO1scQ3y/dmSI+MEQrvvkvEkKpTWIyU6C90zkYNOtlGhEEbGymy0IoQZ3ZkIor56qRchAVgzueyXvmaK934+lRR6J3eFkBcbL23tWrh64jFjNawakm6yaA+ShPtJEnDlszhnusP5lIol3s/7Xl6jr5eklo67sqdC7UUuIJ3t72nzQyCkcu65Ribs1wqrHZ+bSU3tnQg0gxbPNbefkyEZOhovbKDgoUUyGZwmLg5Ctb5rWqu7XxUkQIp3tYcvHMAsqHHZeNVtQV642457luE+L2SCQEGLNFYfCvZ+xUzS1m8OjvfJ3pOKPR/P1cXBqM19RHU0uoOi/mEkJu3IUehvprH8MYe2u5Sr+K0aBl8lkvQq9haj06yue+2hnwu12X+g0SbjnadUNkA9mw+j/W4zPVwhpPdjV/cepo+OYXL1ZtvtxA+RWtv7jmQ12NBX5WcVdKM3nUlVTXrpL8fKhBO+MZ9eetSJN8VMGkddDsNHI2nSa9+7zA/cdzBuaA9Pmkh3h1J/56+gDjmOQrWqH7D0bVDSAxyE4Sxp/p1w2P02AwdBFHlyY1URPBCr3u7uvr1HlkGzibOt7AcspxHauDGHTEO3+OOk65oYXTZz95KdNIdRm3d6K3DVRS3vpXEAMxU6Hqjw+JFEWDMTqrQn4d3g5mJMQq/LuREP4lDgb24fvN6il5ltQozleLsLPfTOwSa/xCVS2Yv8zWHuWrbFjVP5AIWZ+TRUt4dEG99H/sxT1USC/GnMySPSiBVVCfaT6WFOjN8BNcA20QtNcW1RMmPot+2aDA7bzWkfRpKqKCX2egOSpn7FC0L/OlocSaIqoZULQgrF1O77UT0nKulMc01Dm9/O9+2VrzZ4TInCGTwmRfEf2W/v69XSIYZrF9UBy5F84l6yxllfySCIvj3kEll49BjzNeKwjf/9c54Ce0aO3a8ONBpVdUBdgBX/NcxrcyBDjLye7TiOzeExtI2rWW+4vZG73abze2a4i4m29QwDfTQVlVvcwA/ccAMn3KTTspDvFTBvvGnMLh1CfrusvIOb8i0HDYY0PbJwVOfTPVlhc3MlKhc+k5Sf/Pnpj6EdUTo2mSp91lktNr74D2CFzWWpkhy4yhgk5eavx0oHdrg53mGyKbs/Xc8zY6JUxLwgE24GbfbeacL1twg0eBifu0mH2WxCcpvrepJD/qyRCXcIBYJl7cYX/wntJonSJRfs5BqgXYj/I0lkwASUb3c/dT5VFmID/pw1pAaUUUoiJ2XiQyiiw7m7EbpWFzCTXawNwthC1Ze6+CVGo5y9I9ZlxZKT3StEknpJoiMMCQv0xwz5uLODDrgp3wL1XAmonVKIuqbQZek80UFeXFcg8lb9jPhB3kXQV2h9J8OrYIMGxLmFmqD5ZK+n82PMsfAtJdDU07GH+MotLPoNjp0cDOFihNi0FfYUoF2iY7ON1ZS2aYOwF+APy1x9bJs7n1jZSdc+8Gv3vfDDKMQq7Ar4xynkzTeGRoci+4R/nMKSO7vk6NLGS/jnKaT5vnwkrdo1WP3rFMY6g79Dtt2FXQlAloo3vLyE12+W0gZ874L803JiHVDYOCLjb3jt3rUE1j1zCoWKCDmATdOx9wQav+XgaWOaLSNT9oM25wnuCuvaLgWrrd11KGSUvxIYh4MWshR8i85Her9kAVPOpQdGjS7i0pRlLj7gHzILuLwQuAyaXdCGj5f1xsJmKUQxur93rX3Qq8/NxpEy07ClhahAhjb7VhMRXgFkEARb5nrDMXfZMcInrnsHqaJXjxufu5ebYxexkJC55RKKSBkRvkFJUnxHRN5AQ3H3d6v3f8Qjwr3ew9/lCFSnpNe/8JMncTAXYDvmtDW0B70DMK4k3yxdBmPM1/0jeZGICd2e8QPk0LSZU+G+p85FKWc+NQdMNXOUnff3tEWpwctWhH27SWgx+faJ/CETNY3L6c5nmX6d4JgKCWqcsn9Z128jjGv6yH1PUMRe68f0yShTC6/ubU5GkMwQUaTunDoRyQ0T7tjuTkBZq2F5f9MvNPMc8nZarCWy22QtPJ5+HN2t6vUi0K3afQqYq5FFqEquadY8OxxWlguNxfYqM8wXKft51fzYIUyD/UChQsKmbJ5WeYmsZh532XGlODoWBYROsgOZZWV3LN1HnTUcf+D2wweYaZpc0VH4a9+87bIV/gjvSt0IauaGamN0WhVHplLo4viEJE3AdcSinGGpu2Sxz1ULyaiyX8e9Rbm1QP6aZFv3NChoKB/42AG48ZQIbwz7N8xOddtyDycvN04Xqftltd7UySnXn5UUON+I26fPh1pzMA/w6RNyJgF0Qia6bLTSXOLal/HWjwrFXliaGnXrTo1zdhsfGxlOFkfdIsTUxxMQuW1nWP0B1A14bwEnlx0FXkl9NFL9S9PJcZxTvt8AIazKUXJhUsRf3tO20egv0G8ZKVhRy4yU4CDgHFHzFuZDHGUPxR8wSQFu86g5pHhbV8xJ1o1pVEJjFnLQcaA0B+6u23L6sLRxxBs+bGdT03v0IFBafaLEmwMZlYxJgP2LRm6rjgjq2tf8UAIeuE3Y6k2wfsqnXST9ZOG237rjg7raNqho5kDKrFUa502wl36xGSrWZ95pXX71QROobS58udh7FC/ZtvnKgy5AycqXlGdh96NtRMHB6UCGry933xpOfb7+HyVLdrW7v+a4AppxmfqBlyhpyfNmu+nK/gN5D1DH6h02++hxwS5GXrBbvKkF7+UXMshyNT6Pbxcz6bV8yzNj+48sx+fF4jxednujo+gbaXrNLIjXHzoY6BX3tXzxxRdffPHFF1988cUXX3zxxRcF/AfivK15zgdHTwAAAABJRU5ErkJggg==','2017-07-29 09:22:13','2017-07-29 13:43:56','{\"course_prerequisites\":[\"javascript \",\"knowledge of basic oops\"],\"training_highlights\":[\"kanika\",\"monika\"],\"chapter_name\":[\"kanika \",\"monika\"]}',NULL,120,NULL),(80,'.Net technologies',NULL,0,NULL,NULL,'2017-07-29 10:34:30','2017-07-29 10:34:30',NULL,NULL,NULL,NULL),(81,'.Net technologies','asp.net',80,NULL,NULL,'2017-07-29 10:34:30','2017-07-29 10:34:30',NULL,NULL,NULL,NULL),(82,'.Net technologies','webapi',80,NULL,NULL,'2017-07-29 10:34:30','2017-07-29 10:34:30',NULL,NULL,NULL,NULL),(83,'.Net technologies','wcf',80,NULL,NULL,'2017-07-29 10:34:30','2017-07-29 10:34:30',NULL,NULL,NULL,NULL),(84,'Testing',NULL,0,NULL,NULL,'2017-07-29 10:35:03','2017-07-29 10:35:03',NULL,NULL,NULL,NULL),(85,'Testing','Manual Testing',84,NULL,NULL,'2017-07-29 10:35:03','2017-07-29 10:35:03',NULL,NULL,NULL,NULL),(86,'Testing','Selenium',84,NULL,NULL,'2017-07-29 10:35:03','2017-07-29 10:35:03',NULL,NULL,NULL,NULL),(87,'Testing','Automation QTP',84,NULL,NULL,'2017-07-29 10:35:03','2017-07-29 10:35:03',NULL,NULL,NULL,NULL),(88,'PHP Courses',NULL,0,NULL,NULL,'2017-07-29 10:35:23','2017-07-29 10:35:23',NULL,NULL,NULL,NULL),(89,'PHP Courses','laravel',88,NULL,NULL,'2017-07-29 10:35:23','2017-07-29 10:35:23',NULL,NULL,NULL,NULL),(90,'PHP Courses','magento',88,NULL,NULL,'2017-07-29 10:35:23','2017-07-29 10:35:23',NULL,NULL,NULL,NULL),(91,'PHP Courses','zend',88,NULL,NULL,'2017-07-29 10:35:23','2017-07-29 10:35:23',NULL,NULL,NULL,NULL),(92,'Java Technologies',NULL,0,NULL,NULL,'2017-07-29 15:40:34','2017-07-29 15:40:34',NULL,NULL,NULL,NULL),(93,'Java Technologies','eclipse',92,NULL,NULL,'2017-07-29 15:40:34','2017-07-29 15:40:34',NULL,NULL,NULL,NULL),(94,'Java Technologies','hybernate',92,NULL,NULL,'2017-07-29 15:40:34','2017-07-29 15:40:34',NULL,NULL,NULL,NULL),(95,'Java Technologies','spring',92,NULL,NULL,'2017-07-29 15:40:34','2017-07-29 15:40:34',NULL,NULL,NULL,NULL),(96,'php',NULL,0,NULL,NULL,'2017-07-29 17:32:40','2017-07-29 17:32:40',NULL,NULL,NULL,NULL),(97,'php','laravel',96,NULL,NULL,'2017-07-29 17:32:40','2017-07-29 17:32:40',NULL,NULL,NULL,NULL),(100,'Sample',NULL,0,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL),(101,'Sample','test',100,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL),(102,'Sample','test',100,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL),(103,'Sample','test',100,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL),(104,'Sample','test',100,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL),(105,'Sample','test',100,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL),(106,'Sample','test',100,NULL,NULL,'2017-07-31 10:09:10','2017-07-31 10:09:10',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `syllabus`
--

DROP TABLE IF EXISTS `syllabus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `syllabus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chapter_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chapter_topic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_course_id` int(10) unsigned DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `course_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `syllabus`
--

LOCK TABLES `syllabus` WRITE;
/*!40000 ALTER TABLE `syllabus` DISABLE KEYS */;
INSERT INTO `syllabus` VALUES (1,NULL,NULL,79,'The .NET Framework is a new computing platform developed by Microsoft that simplifies application development task of developers. You can use the .NET Framework to develop apps for the desktop, web, mobile devices and much more. At 3RI Technologies, the team of experts in .Net has specially designed this Job oriented Web development using .Net Professional course. In our Microsoft dot net training program, you will learn starting from basic HTML to advanced level of .net Framework .',77,1,'2017-07-29 09:23:44','2017-07-29 13:23:07'),(2,NULL,NULL,79,'The .NET Framework is a new computing platform developed by Microsoft that simplifies application development task of developers. You can use the .NET Framework to develop apps for the desktop, web, mobile devices and much more. At 3RI Technologies, the team of experts in .Net has specially designed this Job oriented Web development using .Net Professional course. In our Microsoft dot net training program, you will learn starting from basic HTML to advanced level of .net Framework . This course covers web development foundation course(HTML/CSS/Javascript) plus C# and ASP.net. 3RI Technologies, also have specially designed courses for MVC framework, WCF , WPF training for professional people.',77,1,'2017-07-29 10:16:25','2017-07-29 13:23:11'),(3,NULL,NULL,79,'The .NET Framework is a new computing platform developed by Microsoft that simplifies application development task of developers. You can use the .NET Framework to develop apps for the desktop, web, mobile devices and much more. At 3RI Technologies, the team of experts in .Net has specially designed this Job oriented Web development using .Net Professional course. In our Microsoft dot net training program, you will learn starting from basic HTML to advanced level of .net Framework . This course covers web development foundation course(HTML/CSS/Javascript) plus C# and ASP.net. 3RI Technologies, also have specially designed courses for MVC framework, WCF , WPF training for professional people.',77,1,'2017-07-29 10:17:23','2017-07-29 13:23:16'),(4,NULL,NULL,78,'AngularJS is a very powerful JavaScript Framework. It is used in Single Page Application (SPA) projects. It extends HTML DOM with additional attributes and makes it more responsive to user actions. AngularJS is open source, completely free, and used by thousands of developers around the world. It is licensed under the Apache license version 2.0.',77,1,'2017-07-29 13:30:36','2017-07-29 13:30:36'),(5,NULL,NULL,78,'AngularJS is a very powerful JavaScript Framework. It is used in Single Page Application (SPA) projects. It extends HTML DOM with additional attributes and makes it more responsive to user actions. AngularJS is open source, completely free, and used by thousands of developers around the world. It is licensed under the Apache license version 2.0.',77,1,'2017-07-29 13:32:16','2017-07-29 13:32:16'),(6,NULL,NULL,78,'AngularJS is a very powerful JavaScript Framework. It is used in Single Page Application (SPA) projects. It extends HTML DOM with additional attributes and makes it more responsive to user actions. AngularJS is open source, completely free, and used by thousands of developers around the world. It is licensed under the Apache license version 2.0.',77,1,'2017-07-29 13:34:07','2017-07-29 13:34:07'),(7,NULL,NULL,79,'react is a javascript framework',77,1,'2017-07-29 13:43:56','2017-07-29 13:43:56'),(8,NULL,NULL,78,'AngularJS is a very powerful JavaScript Framework. It is used in Single Page Application (SPA) projects. It extends HTML DOM with additional attributes and makes it more responsive to user actions. AngularJS is open source, completely free, and used by thousands of developers around the world. It is licensed under the Apache license version 2.0.',77,1,'2017-07-31 10:15:45','2017-07-31 10:15:45');
/*!40000 ALTER TABLE `syllabus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (8,NULL,NULL,'Mannu','1','kroy@gmail.com','$2y$10$OMjLf6eM55RmKPGbFE0u6Opf2FxcbN8ckiPBQEjeNrNtFMzZU3hn6',NULL,1,'2017-03-12 17:53:32','2017-04-05 13:27:10'),(14,NULL,NULL,'kandy','2','kroy@mailinator.com','$2y$10$nyFnVPqvIbQY30BDxALJauf2j9.ofMJsUHhQBZ57cVA5wovuKCexK',NULL,0,'2017-03-12 18:16:25','2017-06-17 16:17:25'),(15,NULL,NULL,'Kanik','1','kanika@mailinator.com','$2y$10$oRvXVewMiygBMQrHbw6.i.gvS70ugNvcsRhavlksWuog87RlkhB.u',NULL,0,'2017-06-17 13:06:37','2017-06-17 16:17:29'),(16,'kandy','roy',NULL,'','kr1@mailinator.com','$2y$10$ssmjl/s9/uyB9nok2Xpr7ewVkCkut9hLhOugn3wvo4MgwwlOuBnP6',NULL,0,'2017-06-17 22:51:28','2017-06-17 22:51:28'),(17,'kandy','roy',NULL,'','kr@mailinator.com','$2y$10$cV7ZCk.z4FdDBc9e4UMuQO5YAZmLUWmQjYHfqTv1uG2UByH18Z4f.',NULL,0,'2017-06-17 22:53:40','2017-06-17 22:53:40'),(18,'kandy','roy',NULL,'','kr3@mailinator.com','$2y$10$JRQSDc/JCARELmpn6DXPNuJ928jfhAo2/biUi3ilg/e9mItpdOu6K',NULL,0,'2017-06-17 22:55:39','2017-06-17 22:55:39'),(19,'kandy','roy',NULL,'','kr33@mailinator.com','$2y$10$OFU5waJRd5nMonnNN5cqF.S9/tdr6SLe0ZqzybSwSze8ZElwOLO3.',NULL,0,'2017-06-17 22:59:13','2017-06-17 22:59:13'),(20,'kundan',NULL,NULL,'','kroyss@mailinator.com','$2y$10$vL1s5/0ZeY0eFVKOXMgj0OWlyFUVN4yyYJmuQR0CkgbSS/w4hCIE6',NULL,0,'2017-06-17 23:36:41','2017-06-17 23:36:41'),(21,'kundan',NULL,NULL,'','kroy.iips@gmail.com','$2y$10$1v1Pw8AEHBg0C1usXqxGSumJQW7p5tt/w.EhRw8L74J20o2sW1OcW',NULL,0,'2017-06-17 23:39:12','2017-06-18 22:15:19'),(22,'kundan',NULL,NULL,'','dsds@mailinator.com','$2y$10$3tb6yTRqfsrZiDvDc63CYOYpsyo3YUmqqjdtjSMhks9TSGTUZXzIm',NULL,1,'2017-06-18 21:06:45','2017-06-18 21:10:23'),(23,'kkundan',NULL,NULL,'','sexkds@mailinator.com','$2y$10$8y3bB/qdOzv0KyQyfjPA3.KaZuul71LQBIyT7SGDexVtz.EVwtb0y',NULL,0,'2017-06-18 21:26:48','2017-06-18 21:26:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'gsure2'
--

--
-- Dumping routines for database 'gsure2'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-25 12:00:04
