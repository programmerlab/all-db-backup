-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: ecart
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ecart`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ecart` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ecart`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@admin.com','$2y$10$FxlETUgr3Y2GiCXxji0axeKYJC5hOXfOk6.W4zjUz4SKqRrIEcKQy','Vx9jRRhel96nb8wcz1JNa69oWBrFeVLSQxtyq5rzqok5IV1gst4Plo9ANVkR',NULL,'2017-04-28 13:20:29',''),(5,'admin2@gmail.com','$2y$10$uoNjJQyK46bOUZNkv4C4ruwfZJnnU8wo7TRzt7Ex1tx/gkdge.TIm','6yk7lJWSXtNDvbrnYvo46WcjLgedxqPZAShbUxzWGJMvm7VnR1q1A97eh8E4','2017-03-19 10:22:04','2017-03-19 10:37:31','');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `photo` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_category_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(10) unsigned DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (79,'GRAINS & PULSES','grains-pulses','GRAINS & PULSES','GRAINS & PULSES',0,1,1,'2017-04-20 20:23:11','2017-04-20 20:23:11'),(80,'OIL & GHEE','oil-ghee','OIL & GHEE','OIL & GHEE',0,1,1,'2017-04-20 20:24:25','2017-04-20 20:24:25'),(81,'SALT & SUGAR','salt-sugar','SALT & SUGAR','SALT & SUGAR',0,1,1,'2017-04-20 20:24:50','2017-04-20 20:24:50'),(82,'AATA','aata','AATA','AATA',0,1,1,'2017-04-20 20:25:09','2017-04-20 20:25:09'),(83,'TEA & COFFEE','tea-coffee','TEA & COFFEE','TEA & COFFEE',0,1,1,'2017-04-20 20:25:30','2017-04-20 20:25:30'),(84,'COSMETICS','cosmetics','COSMETICS','COSMETICS',0,1,1,'2017-04-20 20:25:52','2017-04-20 20:25:52'),(85,'NUTS & DRY FRUIT','nuts-dry-fruit','NUTS & DRY FRUIT','NUTS & DRY FRUIT',0,1,1,'2017-04-20 20:26:08','2017-04-20 20:26:08'),(86,'MASALE - SPICES','masale-spices','MASALE - SPICES','MASALE - SPICES',0,1,1,'2017-04-20 20:26:56','2017-04-20 20:26:56'),(87,'Masoor Dal','masoor-dal','Masoor Dal','Masoor Dal',79,2,1,'2017-04-20 20:30:06','2017-04-20 20:30:06'),(88,'Green Mung Dal','green-mung-dal','Green Mung Dal','Green Mung Dal',79,2,1,'2017-04-20 20:30:26','2017-04-20 20:30:26'),(89,'Arhar/Toor Dal','arhartoor-dal','Arhar/Toor Dal','Arhar/Toor Dal',79,2,1,'2017-04-20 20:30:47','2017-04-20 20:30:47'),(90,'Chana Dal','chana-dal','Chana Dal','Chana Dal',79,2,1,'2017-04-20 20:31:43','2017-04-20 20:31:43'),(91,'Urad Dal','urad-dal','Urad Dal','Urad Dal',79,2,1,'2017-04-20 20:32:11','2017-04-20 20:32:11'),(92,'Ghee','ghee','Ghee','Ghee',80,2,1,'2017-04-20 20:33:00','2017-04-20 20:33:00'),(93,'Cow Ghee','cow-ghee','Cow Ghee','Cow Ghee',80,2,1,'2017-04-20 20:33:25','2017-04-20 20:33:25'),(94,'Soyabean Oil','soyabean-oil','Soyabean Oil','Soyabean Oil',80,2,1,'2017-04-20 20:33:54','2017-04-20 20:33:54'),(95,'Mustard Oil','mustard-oil','Mustard Oil','Mustard Oil',80,2,1,'2017-04-20 20:34:18','2017-04-20 20:34:18'),(96,'OTHER PRODUCTS','other-products','OTHER PRODUCTS','OTHER PRODUCTS',0,1,1,'2017-04-20 20:44:34','2017-04-20 20:44:34');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupans`
--

DROP TABLE IF EXISTS `coupans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coupan_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `start_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupans`
--

LOCK TABLES `coupans` WRITE;
/*!40000 ALTER TABLE `coupans` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_supports`
--

DROP TABLE IF EXISTS `customer_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_supports` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `support_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_supports`
--

LOCK TABLES `customer_supports` WRITE;
/*!40000 ALTER TABLE `customer_supports` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dealers`
--

DROP TABLE IF EXISTS `dealers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dealers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dealer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dealer_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dealers`
--

LOCK TABLES `dealers` WRITE;
/*!40000 ALTER TABLE `dealers` DISABLE KEYS */;
/*!40000 ALTER TABLE `dealers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_100000_create_password_resets_table',1),('2017_03_19_212358_create_admin_table',1),('2017_03_19_212358_create_categories_table',1),('2017_03_19_212358_create_products_table',1),('2017_03_19_212358_create_users_table',1),('2017_03_19_212400_add_foreign_keys_to_products_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `page_content` text,
  `creeated_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_keys`
--

DROP TABLE IF EXISTS `product_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `secret_key` text COLLATE utf8_unicode_ci,
  `user_id` int(10) unsigned DEFAULT NULL,
  `validity_year` int(10) unsigned DEFAULT NULL,
  `dealer_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_keys`
--

LOCK TABLES `product_keys` WRITE;
/*!40000 ALTER TABLE `product_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_category` int(10) unsigned DEFAULT NULL,
  `product_sub_category` int(10) unsigned DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `qty` int(10) unsigned DEFAULT '1',
  `discount` float(10,2) NOT NULL DEFAULT '0.00',
  `description` mediumtext COLLATE utf8_unicode_ci,
  `photo` mediumtext COLLATE utf8_unicode_ci,
  `product_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validity` int(10) unsigned DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `total_stocks` int(10) unsigned DEFAULT NULL,
  `available_stocks` int(10) unsigned DEFAULT NULL,
  `views` int(10) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_category` (`product_category`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`product_category`) REFERENCES `categories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (15,'Masoor Dal',87,NULL,107.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Colour</td>\r\n			<td style=\"white-space:pre-wrap\">orange</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493383874masoor-dal2.jpg',NULL,NULL,NULL,NULL,NULL,3,'2017-04-28 12:51:14','2017-04-28 18:00:04'),(16,'Sabut Black Masoor Dal',87,NULL,107.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Colour</td>\r\n			<td style=\"white-space:pre-wrap\">Black</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384095img_3451.jpg',NULL,NULL,NULL,NULL,NULL,7,'2017-04-28 12:54:55','2017-04-28 17:59:51'),(17,'Green Moong Dal',88,NULL,107.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Colour</td>\r\n			<td style=\"white-space:pre-wrap\">Green</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384228Maash.jpg',NULL,NULL,NULL,NULL,NULL,1,'2017-04-28 12:57:08','2017-04-28 12:57:08'),(18,'Chilka Green Moong Dal',88,NULL,107.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Colour</td>\r\n			<td style=\"white-space:pre-wrap\">Green</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384285green-chilka.jpg',NULL,NULL,NULL,NULL,NULL,1,'2017-04-28 12:58:05','2017-04-28 12:58:05'),(19,'Arhar Dal/Toor Dal',89,NULL,195.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Description</td>\r\n			<td style=\"white-space:pre-wrap\">Add a punch of nutrition to your diet with Reliance Good Life Toor Dal Pulses. From main course dishes like Dal Tadka and Sambhar to various other delectable dishes, this pulse makes for a versatile ingredient.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Key Features</td>\r\n			<td style=\"white-space:pre-wrap\">Rich in essential nutrients Versatile pulse</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">2 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Other Language Name</td>\r\n			<td style=\"white-space:pre-wrap\">Toor Dal</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Disclaimer</td>\r\n			<td style=\"white-space:pre-wrap\">Every effort is made to maintain accuracy of all information. However, actual product packaging and materials may contain more and/or different information. It is recommended not to solely rely on the information presented.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384441toor-dal.jpg',NULL,NULL,NULL,NULL,NULL,1,'2017-04-28 13:00:41','2017-04-28 13:00:41'),(20,'Chana Dal',90,NULL,114.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 KG</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384548chana-dal-1.jpg',NULL,NULL,NULL,NULL,NULL,7,'2017-04-28 13:02:28','2017-04-28 13:07:00'),(21,'Sabut Black Urad Dal',91,NULL,112.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 KG</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Colour</td>\r\n			<td style=\"white-space:pre-wrap\">Black</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384662urad-991129.jpg',NULL,NULL,NULL,NULL,NULL,6,'2017-04-28 13:04:22','2017-04-28 17:49:52'),(22,'Chilka Black Urad Dal',91,NULL,128.00,1,0.00,'<table style=\"width:1028px\">\r\n	<thead>\r\n		<tr>\r\n			<th>Highlights</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Unit</td>\r\n			<td style=\"white-space:pre-wrap\">1 KG</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top; width:220px\">Colour</td>\r\n			<td style=\"white-space:pre-wrap\">Black</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1493384717asd.jpg',NULL,NULL,NULL,NULL,NULL,1,'2017-04-28 13:05:17','2017-04-28 13:05:17');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (44,'website_title','Guruhomeshops : India Largest kirana shop','2017-04-15 17:31:06','2017-04-20 13:15:35'),(45,'website_email','info@guruhomeshops.com','2017-04-15 17:31:07','2017-04-20 13:15:35'),(46,'website_url','http://guruhomeshops.com/','2017-04-15 17:31:07','2017-04-20 13:15:35'),(47,'contact_number','+91-9168518310','2017-04-15 17:31:07','2017-04-21 19:52:31'),(48,'company_address','<p>Nagpur , MH 440034</p>\r\n','2017-04-15 17:31:07','2017-04-23 12:43:17'),(49,'banner_image1','149271233901.jpg','2017-04-15 17:31:07','2017-04-20 12:48:59'),(53,'_method','PATCH','2017-04-15 18:06:33','2017-04-15 18:06:33'),(54,'banner_image2','149271236302.jpg','2017-04-20 12:49:23','2017-04-20 12:49:23'),(55,'banner_image3','149271387201.jpg','2017-04-20 12:49:23','2017-04-20 13:14:32');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_billing_addresses`
--

DROP TABLE IF EXISTS `shipping_billing_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_billing_addresses` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address1` text,
  `address2` text,
  `zip_code` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `address_type` tinyint(4) DEFAULT '1',
  `payment_mode` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_billing_addresses`
--

LOCK TABLES `shipping_billing_addresses` WRITE;
/*!40000 ALTER TABLE `shipping_billing_addresses` DISABLE KEYS */;
INSERT INTO `shipping_billing_addresses` VALUES (1,11,NULL,NULL,NULL,' nileshvyas1986@gmail.com','admin@admin.com','343543543',NULL,'dfgdfgfdgfd',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 10:23:08','2017-04-10 10:40:56'),(2,11,NULL,NULL,NULL,' nileshvyas1986@gmail.com','admin@admin.com','256   ',NULL,'mp','mp','452001','kad@gmail.com','123456',NULL,2,NULL,'2017-04-10 10:37:01','2017-04-10 11:29:12'),(3,0,NULL,NULL,NULL,'nileshvyas1986@gmail.com','admin@admin.com',' ',NULL,'',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 12:56:40','2017-04-10 13:01:02'),(4,16,NULL,NULL,NULL,'kundn','kroy.webxpert@gmail.com','456123',NULL,'indore',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 13:39:17','2017-04-10 13:39:17'),(5,16,NULL,NULL,NULL,'kandu','kanu@sdfdk.cso','45421212',NULL,'indore sds','dgdfgfdg','89089','indore','mp',NULL,2,NULL,'2017-04-10 13:39:41','2017-04-10 13:39:41'),(6,15,NULL,NULL,NULL,'nileshvyas1986@gmail.com','kroy.iips@gmail.com',' 456123 ',NULL,'4',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 16:31:26','2017-04-14 16:02:37'),(7,15,NULL,NULL,NULL,'nileshvyas1986@gmail.com','admin@admin.com',' 456123 ',NULL,'4','fsdfds','34324324','kad2@gmail.com','kad2@gmail.com',NULL,2,NULL,'2017-04-10 16:31:50','2017-04-14 16:02:40'),(8,18,NULL,NULL,NULL,'vaibhav','v@gmail.com','8794564',NULL,'indore',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-10 16:54:45','2017-04-10 16:54:46'),(9,18,NULL,NULL,NULL,'va','v@gmail.com','789546465',NULL,'iuh','hkjh','4545415','root','root',NULL,2,NULL,'2017-04-10 16:55:23','2017-04-10 16:55:23'),(10,19,NULL,NULL,NULL,'kundan','kroy.iips@gmail.com','8103194076',NULL,'indore mp 452001',NULL,NULL,NULL,NULL,NULL,1,NULL,'2017-04-13 14:52:34','2017-04-13 14:52:34'),(11,19,NULL,NULL,NULL,'kundan roy','kroy.zend@gmail.com','8103194076',NULL,'indore','vijay nagar mp','452001','indore','mp',NULL,2,NULL,'2017-04-13 14:53:15','2017-04-13 14:53:15');
/*!40000 ALTER TABLE `shipping_billing_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `support_type` varchar(255) DEFAULT NULL,
  `subject` tinytext,
  `description` text,
  `ticket_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_key_id` int(10) unsigned DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `coupan_id` int(11) unsigned DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_price` float(10,2) DEFAULT NULL,
  `discount_price` float(10,2) DEFAULT '0.00',
  `transaction_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user3','user3','user3@user3.com','$2y$10$Lz/T3Dag7MEdSq0rReZ4E.7y8jcDnPVMLT/sboOKQcVuv6kdyPWz6',NULL,'',0,'0000-00-00 00:00:00','2017-03-16 22:11:19'),(2,'user2','user2','user2@user2.com','$2y$10$Hak7CISZtp53vF2V7tP1/uRhXs8mqjebuRwblENnm5L4zFi2xSEuu',NULL,'',0,'2016-12-04 17:47:05','2017-03-16 22:10:46'),(3,'user1','user1','user1@user1.com','$2y$10$wdUo8O4gKFbTeKlA4rdw6uMTRBGQNzIjm/xvHTmcBFiCQrZ3HMboe',NULL,'',1,'2016-12-04 17:47:53','2017-03-16 22:10:27'),(4,'kundan','roy','test@gmail.com','$2y$10$ZYWi19RyDm1M/5JE1/ZPvuz0DaBKLR5xK1MVAuwUMmRH/D1FbpYqO',NULL,'',1,'2017-03-16 18:18:54','2017-03-16 18:20:23'),(8,'sdmail.com','','user1s@user1.com','$2y$10$2.K1aGZmgtRokQriv9PtKuZGxodDhccLrf/NMdsa9xc.uIJhc6flu',NULL,NULL,0,'2017-03-17 21:40:47','2017-03-17 21:40:47'),(10,'Kandy','','kandyroy@gmail.com','$2y$10$ZYWi19RyDm1M/5JE1/ZPvuz0DaBKLR5xK1MVAuwUMmRH/D1FbpYqO',NULL,NULL,0,'2017-03-19 23:26:01','2017-03-19 23:26:01'),(11,'kad','k','kad@gmail.com','$2y$10$qpdQ8GigrG3bRksUEmgbe.cXNgFvjjkcM04RgcHJAHmSlS5oCtcFK',NULL,NULL,0,'2017-04-10 12:11:35','2017-04-10 12:11:35'),(12,'fdfdf','','k1@mailinator.com','$2y$10$Q3q9uh4IoAMmsPypzG37vegTJaeiGMrXguVSMK2XuakV/xs240cgi',NULL,NULL,0,'2017-04-10 18:10:08','2017-04-10 18:10:08'),(13,'kandy','','kandy@mailinator.com','$2y$10$lAzg4PtJc5Dm0MoDcwvXKeSDK0v72zxKkWg48JT5rv7zC.SnKlzkS',NULL,NULL,0,'2017-04-10 18:11:32','2017-04-10 18:11:32'),(14,'kad','','kadw@gmail.com','$2y$10$bPjm/xDgxirBpeb0ytpkL.vwM/Fxmpka8B1b07silC8zZCIxpwMH2',NULL,NULL,0,'2017-04-10 18:20:43','2017-04-10 18:20:43'),(15,'kad','','kad2@gmail.com','$2y$10$YwQ85PyV0xioJtEH8LBPHultXA6TJWDWTKhj.cb.litv1.Da.i5f.',NULL,NULL,0,'2017-04-10 18:45:43','2017-04-10 18:45:43'),(16,'kad','','kads2@gmail.com','$2y$10$I3vvSafXQC1rK9FFr8NBDOcW7lqUc7h7plDFgpzb4OFg9NW0i1esm',NULL,NULL,0,'2017-04-10 19:08:38','2017-04-10 19:08:38'),(17,'kunda','','roy@sdsd.com','$2y$10$h8KgGLoQgdKgDikG76YsSOvp6Ba.hdj.UdRfN22oFQnXoL0GM6lW6',NULL,NULL,0,'2017-04-10 21:20:14','2017-04-10 21:20:14'),(18,'vaibhav','','vaibhav@gmail.com','$2y$10$ffn2Niy9cD.3Iy6pzOGA6OMW0wtBh9KfmZ0ZRzQ9AiwnoZ6o9ld8m',NULL,NULL,0,'2017-04-10 22:23:40','2017-04-10 22:23:40'),(19,'kundan','','kroy.iips@gmail.com','$2y$10$BW8yh95vKxFalx7gWz3iI..HQY5tvJD1ahHqRIYG8ZnXMzZzKGb2m',NULL,NULL,0,'2017-04-13 20:22:09','2017-04-13 20:22:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ecart'
--

--
-- Dumping routines for database 'ecart'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-23  6:25:05
