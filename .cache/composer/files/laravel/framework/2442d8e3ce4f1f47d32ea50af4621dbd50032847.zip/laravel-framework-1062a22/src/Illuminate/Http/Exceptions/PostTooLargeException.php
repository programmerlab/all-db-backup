<?php

namespace Illuminate\Http\Exceptions;

use Exception;

class PostTooLargeException extends Exception
{
    //
}
