<?php

class Symfony_Component_Debug_Tests_Fixtures_PEARClass
{
}
