## IDE Stubs

These exist to reduce false positive errors on PHPStorm and other IDEs.

They also exist so Psalm has some idea what's going on.

Don't use them in your project.
