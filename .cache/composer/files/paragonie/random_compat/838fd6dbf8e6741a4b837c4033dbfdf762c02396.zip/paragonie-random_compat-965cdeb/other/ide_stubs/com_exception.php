<?php

/**
 * Class COM
 *
 * This is just a stub class.
 */
class com_exception extends Exception
{

}
