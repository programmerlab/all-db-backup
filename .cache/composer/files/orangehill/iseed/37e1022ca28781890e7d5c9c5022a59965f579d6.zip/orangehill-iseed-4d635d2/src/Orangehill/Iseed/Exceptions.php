<?php

namespace Orangehill\Iseed;

class TableNotFoundException extends \RuntimeException
{

}